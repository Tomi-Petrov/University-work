/*
 -------------------------------------------------------
 Project: cp386 a2
 File:  petr3846_cp386_a2.c
 -------------------------------------------------------
 Author:  Tomi Petrov (180638460)
 Version:  2020-11-13
 -------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
	setbuf(stdout, NULL);
	setbuf(stderr, NULL);

	//Variables initialization
	char str1[100];
	char newString[100][100];
	int i, j, counter, current, n, m, processesComplete, total, thirdLineCounter;
	int secondLineIndex, secondLineCurrent, secondLineHighest;
	int arrayCounter = -1;
	int finallyOver = 0;
	int firstTime = 1;

	//Retrieve input
	fgets(str1, sizeof str1, stdin);

	j = 0; counter = 0;
	for(i = 0; i <= (strlen(str1)); i++){
	    if(str1[i] == ' ' || str1[i] == '\0'){
	    	newString[counter][j] = '\0';
	    	counter++;
	        j = 0;
	    }
	    else{
	    	newString[counter][j] = str1[i];
	        j++;
	    }
	}

	//Original two numbers inputed
	int num1 = atoi(newString[0]);
	int num2 = atoi(newString[1]);

	//n and m values
	n = (num1 * 2) + 1;
	m = num2;

	//Array variable initialization
	int processes[n][m];
	int isDone[num1];
	int checkIfDone[num1];
	int thirdLine[num1];
	int secondLine[num1];

	//Retrieving all other inputs
	for(int k = 0; k < n; k++){
		fgets(str1, sizeof str1, stdin);

		j = 0; counter = 0;
		for(i = 0; i <= (strlen(str1)); i++){
			if(str1[i] == ' '||str1[i]=='\0'){
				newString[counter][j] = '\0';
			    counter++;
			    j = 0;
			}
			else{
			    newString[counter][j] = str1[i];
			    j++;
			}
		}
		for(i = 0; i < counter; i++){
			current = atoi(newString[i]);
			processes[k][i] = current;
		}
	}

	for(i = 0; i < num1; i++){
		checkIfDone[i] = 0;
	}

	//Solving the deadlock problem
	while(finallyOver == 0){
		thirdLineCounter = -1;
		processesComplete = 1;

		//Operates until deadlock occurs
		while(processesComplete == 1){
			processesComplete = 0;
			//checking for no resource requests
			for(i = 0; i < num1; i++){
				if(checkIfDone[i] == 0){
					total = 0;
					for(j = 0; j < num2; j++){
						if(processes[i][j] > processes[n - 1][j]){
							total += processes[i][j];
						}
					}
					//If no resource requests
					if(total == 0){

						for(int q = 0; q < num2; q++){
							processes[n - 1][q] = (processes[n - 1][q]) - (processes[i][q]);
							processes[i][q] = 0;
						}

						//Adjusting counters
						processesComplete = 1;
						arrayCounter += 1;
						thirdLineCounter += 1;
						isDone[arrayCounter] = i + 1;
						thirdLine[thirdLineCounter] = i + 1;
						checkIfDone[i] = 1;

						//Adjusting unallocated resource vector
						for(int p = 0; p < num2; p++){
							processes[n - 1][p] += processes[i + num1][p];
							processes[i + num1][p] = 0;
						}
					}
				}
			}
		}

		//Adjusting second line of deadlock output
		for(i = 0; i < num1; i++){
			secondLineCurrent = 0;
			for(j = 0; j < num2; j++){
				secondLineCurrent += processes[i][j];
				secondLineCurrent += processes[i + num1][j];
			}
			secondLine[i] = secondLineCurrent;
		}

		//Checks to see if still in deadlock
		int deadlock = 0;
		for(i = 0; i < num1; i++){
			if(checkIfDone[i] == 0){
				deadlock = 1;
			}
		}

		//If not in deadlock and first time checking
		if(deadlock == 0 && firstTime == 1){
			for(i = 0; i < num1; i++){
				printf("%i", isDone[i]);
				printf(" ");
			}
			finallyOver = 1;
		}

		//If not in deadlock and not first time checking
		else if(deadlock == 0 && firstTime == 0){
			//Prints third line of deadlock output before finishing
			for(i = -1; i < thirdLineCounter; i++){
				printf("%i", thirdLine[i + 1]);
				printf(" ");
			}

			finallyOver = 1;
		}

		//If in deadlock and not first time checking
		else if(deadlock == 1 && firstTime == 0){
			for(i = -1; i < thirdLineCounter; i++){
				printf("%i", thirdLine[i + 1]);
				printf(" ");
			}
			printf("\n");
		}

		//If in deadlock
		if(deadlock == 1){
			//Printing first Line of deadlock output
			for(i = 0; i < num1; i++){
				if(checkIfDone[i] == 0){
					printf("%i", i + 1);
					printf(" ");
				}
			}
			printf("\n");

			//Printing second line of deadlock output
			secondLineHighest = 0;
			secondLineIndex = 0;
			for(i = 0; i < num1; i++){
				if(secondLine[i] > secondLineHighest){
					secondLineHighest = secondLine[i];
					secondLineIndex = i;
				}
			}

			//Terminating a process
			for(int p = 0; p < num2; p++){
				processes[n - 1][p] += processes[secondLineIndex + num1][p];
				processes[secondLineIndex + num1][p] = 0;
			}

			checkIfDone[secondLineIndex] = 1;

			printf("%i", secondLineIndex + 1);
			printf("\n");
		}

		firstTime = 0;
	}

//	printf("\n");
//	for(i = 0; i < n; i++){
//		for(j = 0; j < m; j++){
//			printf("%i", processes[i][j]);
//		}
//		printf("\n");
//	}

	return 0;
}
