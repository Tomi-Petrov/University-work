/*
 -------------------------------------------------------
 Project: cp386 a1
 File:  petr3846_cp386_a1.c
 -------------------------------------------------------
 Author:  Tomi Petrov (180638460)
 Version:  2020-10-19
 -------------------------------------------------------
 */

#include <stdio.h>
#include <time.h>

typedef struct node {
	int value;
    struct node *next;
} node_t;

void enqueue(node_t **head, int val) {
	node_t *new_node = malloc(sizeof(node_t));
	if (!new_node) return;

	new_node->value = val;
	new_node->next = NULL;

	node_t *current = *head;
	if(current != NULL){
		while(current->next != NULL){
			current = current->next;
		}
		current->next = new_node;
	}
	else{
		*head = new_node;
	}

}

int dequeue(node_t **head) {
    node_t *current, *prev = NULL;
    int retval = -1;

    if (*head == NULL) return -1;

    current = *head;

    retval = current->value;
    free(current);

    if (prev)
       prev->next = NULL;

    else
       *head = NULL;

    return retval;
}

void print_list(node_t *head) {
	node_t *current = head;

    while (current != NULL) {
        printf("%d\n", current->value);
        current = current->next;
    }
}

int return_value(node_t *head){
	int final;
	node_t *current = head;

	if(current == NULL){
		final = -1;
	}

	else{
		final = current->value;
	}

	return final;
}

int main(){
	setbuf(stdout, NULL);
	setbuf(stderr, NULL);

	//initializing queues
	node_t *blocked = NULL;
	node_t *ready = NULL;
	node_t *running = NULL;

	//initializing variables
	int keepgoing = 1;
	int time = 0;
	int i = 1;

	//user string input
	char str[20];
	printf("Enter a string: ");
	scanf("%s", &str);

	int processes[strlen(str)][6];

	//table printing
	printf("         ");
	for(int j = 0; j <= strlen(str); j++){
		printf("process ID   ");
	}
	printf("\n");
	printf("TIME          ");

	for(int j = 0; j <= strlen(str); j++){
			printf("%i", j);
			printf("            ");
		}


	//iterative loop
	while(keepgoing == 1){

		int current_running = return_value(running);
		int current_ready = return_value(ready);
		int current_blocked = return_value(blocked);

		//switching processes to running
		//if(current_running == -1 && current_blocked != -1){
			//if(processes[current_blocked][4] % 1000){
				//processes[current_blocked][5] = 2;
				//enqueue(&running, current_blocked);
				//dequeue(&blocked);
			//}
		//}

		if(current_running == -1 && current_ready != -1){
			processes[current_ready][5] = 2;
			enqueue(&running, current_ready);
			dequeue(&ready);
		}


		current_running = return_value(running);

		//managing currently running process
		if(current_running != -1){
			processes[current_running][2] += 50;

			//for I
			if(processes[current_running][0] == 0){
				if(processes[current_running][2] >= 200){
					processes[current_running][5] = 4;
					dequeue(&running);
				}

				else if(processes[current_running][2] == 50 || processes[current_running][2] == 100 || processes[current_running][2] == 150){
					processes[current_running][5] = 3;
					enqueue(&blocked, current_running);
					dequeue(&running);
				}
			}

			//for S
			else if(processes[current_running][0] == 1){
				if(processes[current_running][2] >= 200){
					processes[current_running][5] = 4;
					dequeue(&running);
				}
			}

			//for C
			else{
				if(processes[current_running][2] >= 1000){
					processes[current_running][5] = 4;
					dequeue(&running);
				}
			}
		}


		//Incrementing counters in ready and blocked
		node_t *current_queue = ready;
		int current_value;

		while (current_queue != NULL) {
			current_value = current_queue->value;
		    processes[current_value][3] += 50;
		    current_queue = current_queue->next;
		}

		current_queue = blocked;

		while (current_queue != NULL) {
			current_value = current_queue->value;
			processes[current_value][4] += 50;
			if(processes[current_value][4] == 1000){
				processes[current_value][4] = 0;
				processes[current_blocked][5] = 2;
				enqueue(&ready, current_blocked);
				dequeue(&blocked);
			}
			current_queue = current_queue->next;
		}

		//managing new processes
		if(i <= strlen(str) && (time == 0 || time % 100)){
			if(str[i-1] == 'I'){
				processes[i][0] = 0; // 0 represents "I"

			}

			else if(str[i-1] == 'S'){
				processes[i][0] = 1; // 1 represents "S"

			}

			else{
				processes[i][0] = 2; // 2 represents "C"
			}

			processes[i][1] = i; //process id
			processes[i][2] = 0; //total running time
			processes[i][3] = 0; //total time ready
			processes[i][4] = 0; //total time blocked

			if(return_value(running) == -1){
				enqueue(&running, i);
				processes[i][5] = 2;
			}

			else{
				enqueue(&ready, i);
				processes[i][5] = 1;
			}

			i += 1;
		}

		time += 50;
		current_running = return_value(running);
		current_ready = return_value(ready);
		current_blocked = return_value(blocked);

		//exits the program if all requirements are met
		if(current_running == -1 && current_ready == -1 && current_blocked == -1){
			keepgoing = 0;
		}

		//printing table
		printf("\n");
		printf("%i", time-50);
		printf("-");
		printf("%i", time);
		printf("         ");

		if(current_running == -1){
			printf("running");
		}

		else{
			printf("ready");
		}

		printf("          ");
		for(int k = 1; k <= strlen(str); k++){
			if(processes[k][5] == 1){
				printf("ready");
			}
			else if(processes[k][5] == 2){
				printf("running");
			}
			else if(processes[k][5] == 3){
				printf("blocked");
			}
			else if(processes[k][5] == 4){
				printf("exited");
			}
			else{
				printf("NA");
			}
			printf("          ");
		}
	}

	printf("\n");
	printf("\n");
	printf("Process ID       time running       time ready      time blocked");

	printf("\n");
			printf("0");
			printf("                 ");
			printf("0");
			printf("                 ");
			printf("%i", time);
			printf("                 ");
			printf("NA");
			printf("                 ");

	for(int k = 1; k <= strlen(str); k++){
		printf("\n");
		printf("%i", k);
		printf("                 ");
		printf("%i", processes[k][2]);
		printf("                 ");
		printf("%i", processes[k][3]);
		printf("                 ");
		printf("%i", processes[k][4]);
		printf("                 ");
	}

	return 0;
}
