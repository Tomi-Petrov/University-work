# you may import math, random, string and itertools
"""---------------------------------------------------"""
from ciphers import Simple_Substitution, Vigenere  # you may add other ciphers
import utilities, math

NAME = 'Tomi Petrov'  # <------- edit this to be your name, should match your file name


class Midterm_Info:
    
    def get_first_name(self):
        return 'Tomi'  # <------------- edit this with your first name as in myls
    
    def get_last_name(self):
        return 'Petrov'  # <------------- edit this with your last name as in myls
        
    def get_ID(self):
        return '180638460'  # <------- edit this with your student ID
    
    def get_certification(self):
        return 'I certify that I completed this midterm exam according to academic honesty guidelines. I attest that I did not use any external help, neither in person nor virtually. I understand that failing to abide by the academic honest guidelines may lead to my failure in the course, in addition to other penalties according to the university policies.'  # <------- edit this string with your honor pledge

    def get_comments(self):
        output = 'If you have generic comments that you want the instructor to be aware of'
        output += 'put it in this method'
        return output


""" ----------- Task 0 ----------- """


class Classifier:

    @staticmethod
    def classify1(filenames):
        """
        ----------------------------------------------------
        Parameters:   filenames (list): list of 6 files
        Return:       ciphertypes (list):
                        Atbash file (str)
                        Polybius file (str)
                        Columnar Transposition file (str)
                        Vigenere file (str)
                        Alberti file (str)
                        Shift file (str)
        Description:  Analyzes six files containing arbitrary ciphers
                        and classify them into cipher types
        ---------------------------------------------------
        """ 
        result = ["", "", "", "", "", ""]
        return result
    
    @staticmethod
    def classify2(filenames):
        """
        ----------------------------------------------------
        Parameters:   filenames (list): list of 3 files
        Return:       ciphertypes (list):
                        Permveg file (str)
                        Myszkowski file (str)
                        Simple Substitution file (str)
        Description:  Analyzes six files containing arbitrary ciphers
                        and classify them into cipher types
        ---------------------------------------------------
        """
        result = ["", "", ""]
        return result
    
    @staticmethod
    def classify3():
        permveg_file = 'ciphertext1_Tomi_Petrov.txt'  # <-------- hardcode name of file that contains your Permveg cipher file
        myszkowski_file = 'ciphertext2_Tomi_Petrov.txt'  # <------- hardcode name of file that contains your Myszkowski file
        simple_sub_file = 'ciphertext3_Tomi_Petrov.txt'  # <-------- hardcode name of file that contains your Simple Substitution cipher file
        return permveg_file, myszkowski_file, simple_sub_file

    @staticmethod
    def get_comments():
        output = 'Put any comments regarding Task 0'
        return output

    
""" -------------------- Task 1 ------------------------- """


class Permutation:
    DEFAULT_KEY = 2143
    DEFAULT_PAD = 'Q'    
    
    def __init__(self, key=DEFAULT_KEY, pad=DEFAULT_PAD):
        self.key = key
        self.pad = pad
        
    def set_key(self, key):
        ans = True
        if(Permutation.valid_key(key) == True):
            self.key = key
            
        else:
            self.key = Permutation.DEFAULT_KEY
            ans = False
            
        return ans
    
    def __str__(self):
        ans = "Permutation Cipher:"
        ans = ans + "\n"
        ans = ans + "key = {}, block size = {}, pad = {}".format(self.key, Permutation.get_block_size(self), self.pad)
        return ans
    
    def get_block_size(self):
        strKey = str(self.key)
        ans = len(strKey)
        return ans
    
    def get_key(self):
        return self.key
    
    def get_pad(self):
        return self.pad
    
    def set_pad(self, pad):
        ans = True
        if(len(pad) == 1):
            self.pad = pad
            
        else:
            ans = False
            self.pad = Permutation.DEFAULT_PAD
            
        return ans
    
    @staticmethod
    def valid_key(key):
        ans = True
        strKey = str(key)
        keyLen = len(strKey)
        
        if(keyLen == 0):
            ans = False
        
        elif(strKey.isnumeric() == False):
            ans = False
        
        else:
            for j in range(1, keyLen + 1):
                if(strKey.find(str(j)) == -1):
                   ans = False
                   
        return ans
    
    def encrypt(self, plaintext):
        test1 = utilities.get_positions(plaintext, '\n')
        plaintext = utilities.clean_text(plaintext, '\n')
        
        ans = ""
        cArray = []
        strKey = str(self.key)
        cLen = int(math.ceil(len(plaintext) / len(strKey)))
        
        if((cLen * len(strKey)) > len(plaintext)):
            diff = (cLen * len(strKey)) - len(plaintext)
            plaintext = plaintext + (diff * self.pad)
        
        for i in range(cLen):
            cArray.append(plaintext[i * len(strKey):i * len(strKey) + len(strKey)])
                    
        for i in range(len(cArray)):
            for j in range(len(strKey)):
                currentLetter = cArray[i][int(strKey[j]) - 1]
                ans = ans + currentLetter
        
        ans = utilities.insert_positions(ans, test1)
        
        return ans
    
    def decrypt(self, ciphertext):
        test1 = utilities.get_positions(ciphertext, '\n')
        ciphertext = utilities.clean_text(ciphertext, '\n')
        
        ans = ""
        cArray = []
        strKey = str(self.key)
        cLen = int(math.ceil(len(ciphertext) / len(strKey)))
        
        if((cLen * len(strKey)) > len(ciphertext)):
            diff = (cLen * len(strKey)) - len(ciphertext)
            ciphertext = ciphertext + (diff * self.pad)
        
        for i in range(cLen):
            cArray.append(ciphertext[i * len(strKey):i * len(strKey) + len(strKey)])
                    
        for i in range(len(cArray)):
            for j in range(1, len(strKey) + 1):
                index = strKey.find(str(j))
                currentLetter = cArray[i][index]
                ans = ans + currentLetter
        
        ans = utilities.insert_positions(ans, test1)
        
        keepgoing = True
        while(keepgoing == True):
            if(ans[len(ans) - 1] == self.pad):
                ans = ans[0:len(ans) - 1]
                
            else:
                keepgoing = False
                        
        return ans


class Permveg:
    DEFAULT_KEY = (312, 2143, 'exam')

    def __init__(self, key=DEFAULT_KEY):
        self.key = key
      
    def set_key(self, key):
        ans = True
        
        if(Permveg.valid_key(key) == True):
            self.key = key
            
        else:
            self.key = Permveg.DEFAULT_KEY
            ans = False

        return ans
    
    def get_key(self):
        return self.key
    
    def __str__(self):
        ans = "Permveg Cipher:"
        ans = ans + "\n"
        ans = ans + "key = ({}, {}, '{}')".format(self.key[0], self.key[1], self.key[2])

        return ans
    
    @staticmethod
    def valid_key(key):
        ans = True
        listKey = list(key)
        
        if(isinstance(listKey[0], int) == False or isinstance(listKey[1], int) == False or isinstance(listKey[2], str) == False):
            ans = False
        
        i1 = str(listKey[0])
        i2 = str(listKey[1])
        i3 = listKey[2]

        if(isinstance(key, tuple) == False):
            ans = False
            
        elif(len(i1) != 3 or len(i2) != 4 or len(i3) < 4 or len(i3) > 12):
            ans = False
            
        return ans
    
    def encrypt(self, plaintext):
        p = Permutation()
        p.set_key(self.key[0])
        plaintext = p.encrypt(plaintext)
        p.set_key(self.key[1])
        plaintext = p.encrypt(plaintext)
        
        v = Vigenere()
        v.set_key(self.key[2])
        ans = v.encrypt(plaintext)
        
        return ans
    
    def decrypt(self, ciphertext):
        v = Vigenere()
        v.set_key(self.key[2])
        ciphertext = v.decrypt(ciphertext)
        
        p = Permutation()
        p.set_key(self.key[1])
        ciphertext = p.decrypt(ciphertext)
        p.set_key(self.key[0])
        ans = p.decrypt(ciphertext)
        
        return ans
    
    @staticmethod
    def cryptanalyze(ciphertext):
        
        return "1", "2"

    @staticmethod
    def remove_key_duplication(key):
        return ""
    
    @staticmethod
    def get_comments():
        output = 'Put any comments regarding Task 1'
        return output


""" -------------------- Task 2 ------------------------- """


class Myszkowski: 
    DEFAULT_PAD = 'q'
    DEFAULT_KEY = 'abcb'
    
    def __init__(self, key=DEFAULT_KEY, pad=DEFAULT_PAD):
        self.key = key
        self.pad = pad
    
    def get_key(self):
        return self.key
    
    def set_key(self, key):
        ans = True
        
        if(Myszkowski.valid_key(key) == True):
            self.key = key
            
        else:
            self.key = Myszkowski.DEFAULT_KEY
            ans = False

        return ans

    def __str__(self):
        ans = "Myszkowski Cipher:"
        ans = ans + "\n"
        ans = ans + "key = {}, pad = {}".format(self.key, self.pad)
        
        return ans
        
    def get_pad(self):
        return self.pad
    
    def set_pad(self, pad):
        ans = False
        
        if(isinstance(pad, str) and len(pad) == 1):
            ans = True
            self.pad = pad
            
        else:
            self.pad = Myszkowski.DEFAULT_PAD
            
        return ans
    
    @staticmethod
    def valid_key(key):
        ans = True
        rep = False
        nonRep = False
        
        if(isinstance(key, str) == False):
            ans = False
        
        else:
            special = utilities.get_base("upper")
            test1 = utilities.get_positions(key, special)
            key = utilities.clean_text(key, special)
        
            for i in key:
                if(key.count(i) > 1):
                    rep = True
                    
                else:
                    nonRep = True
             
            if(len(key) < 3):
                ans = False       
                    
            elif(rep == False or nonRep == False):
                ans = False
            
        return ans

    @staticmethod
    def key_order(key):
        key = "".join(dict.fromkeys(key))
        
        base = ' ' + utilities.get_base('all')
        
        valid = True
        arr1 = []
        arr2 = []
        keylen = len(key)
        for i in range(keylen):
            if(base.find(key[i]) != -1):
                arr1.append(base.find(key[i]))
            else:
                valid = False
        if(valid == True):
            arr2 = sorted(range(len(arr1)), key=arr1.__getitem__)
        
        return arr2
    
    def encrypt(self, plaintext):
        assert isinstance(plaintext, str)
        
        test1 = utilities.get_positions(plaintext, ' \n')
        plaintext = utilities.clean_text(plaintext, ' \n')
        
        self.key = "".join(dict.fromkeys(self.key))
        
        ans = ""
        key_order = Myszkowski.key_order(self.key)
        plaintext2 = list(plaintext)
        col = len(self.key)
        row = int(math.ceil(len(plaintext) / col))
  
        padding = int((row * col) - len(plaintext))
        plaintext2.extend(self.pad * padding)
        
        initalArray = [plaintext2[i: i + col] 
        for i in range(0, len(plaintext2), col)]
                
        for i in range(len(initalArray[0])):
            current = key_order[i]
            for j in range(len(initalArray)):
                ans = ans + initalArray[j][current]
        
        ans = utilities.insert_positions(ans, test1)
        
        return ans
    
    def decrypt(self, ciphertext):
        assert isinstance(ciphertext, str)
        
        test1 = utilities.get_positions(ciphertext, ' \n')
        ciphertext = utilities.clean_text(ciphertext, ' \n')
        
        self.key = "".join(dict.fromkeys(self.key))
        
        key_order = Myszkowski.key_order(self.key)
        plaintext2 = list(ciphertext)
        col = len(self.key)
        row = int(math.ceil(len(ciphertext) / col))
        ans = [[0] * col for i in range(row)]
        final = ""
        
        initalArray = [plaintext2[i: i + row] 
        for i in range(0, len(plaintext2), row)]
                
        for i in range(len(initalArray)):
            current = key_order[i]
            for j in range(len(initalArray[0])):
                ans[j][current] = initalArray[i][j]
        
        for i in range(len(ans)):
            for j in range(len(ans[0])):
                final = final + ans[i][j]
                
        final = utilities.insert_positions(final, test1)
        
        while(final[len(final) - 1] == self.pad):
            final = final[:-1]
        
        return final
    
    @staticmethod
    def cryptanalyze_dict(args=[None, '', -1]):
        """
        ----------------------------------------------------
        Parameters:   args (list):
                        dict_file (str): default = None
                        known_chars (str): default = ''
                        length (int): defualt = -1
        Return:       keys (list)
        Description:  Analyzes a dictionary file and extracts
                        Myszkowski keys based on args
        ----------------------------------------------------
        """
        ans = []
        for i in range(100):
            ans.append("")
            
        return ans
    
    @staticmethod
    def cryptanalyze(ciphertext, args): 
        """
        ----------------------------------------------------
        Parameters:   args (list):
                        dict_file1 (str): file for dictionary attack
                        dict_file2 (str): file for checking for plaintext
                        threshold (float): threshold for is_plaintext
        Return:       key (str)
                      plaintext (str)
        Description:  Cryptanlaysis of Myszkowski cipher
                      Uses dictionary attack
        ----------------------------------------------------
        """       
        return "", ""
    
    @staticmethod
    def get_comments():
        output = 'Put any comments regarding Task 2'
        return output


""" ----------- Task 3 ----------- """


class Task3:

    @staticmethod
    def get_output(ciphertext):
        s = Simple_Substitution()
        sub = 'abcdef...'  # <----- hard-code your key here
        key = (sub, 'abcdefghijklmnopqrstuvwxyz ,;-:?.')
        s.set_key(key)
        plaintext = s.decrypt(ciphertext)
        return sub, plaintext
    
    @staticmethod
    def get_comments():
        output = 'Put any comments regarding Task 3'
        return output
    
