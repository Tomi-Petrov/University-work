"""
-----------------------------
Name: Tomi Petrov
ID: 180638460
-----------------------------
"""

DICT_FILE = 'engmix.txt'
PAD = 'q'


def debug(ciphertext, size=200):
    """
    ----------------------------------------------------
    Parameters:   ciphertext (str)
                  size (int): max characters to display in debug console
    Return:       -
    Description:  Debugging tool for Simple Substitution Cipher
                  Supports two commands:
                      replace <char1> with <char2>
                      end
    ---------------------------------------------------
    """
    base_str = 'abcdefghijklmnopqrstuvwxyz ,;-:?.'
    sub_str = ['-' for _ in range(len(base_str))]
    
    _ = get_positions(ciphertext, '\n')
    ciphertext = clean_text(ciphertext, '\n')
    
    plaintext = ['-' for i in range(len(ciphertext))]
    print('Ciphertext:')
    print(ciphertext[:size])
    print()
    command = input('Debug Mode: Enter Command: ')
    input('Description: ')
    print()
    
    while command != 'end':
        sub_char = command[8].lower()
        base_char = command[15].lower()
            
        if base_char in base_str:
            indx = base_str.index(base_char)
            sub_str[indx] = sub_char
        else:
            print('(Error): Base Character does not exist!\n')

        print('Base:', end='')
        for i in range(len(base_str)):
            print('{} '.format(base_str[i]), end='')
        print()
        print('Sub :', end='')
        for i in range(len(sub_str)):
            print('{} '.format(sub_str[i]), end='')
        print('\n')

        print('ciphertext:')
        print(ciphertext[:size])
        for i in range(len(plaintext)):
            if ciphertext[i].lower() == sub_char:
                plaintext[i] = base_char
        print('plaintext :')
        print("".join(plaintext[:size]))
        print('\n_______________________________________\n')
        command = input('Enter Command: ')
        if command != 'end':
            input('Description: ')
        print()
    return

    
'______________________________________________________________________________'


def get_base(base_type):
    """
    ----------------------------------------------------
    Parameters:   base_type (str) 
    Return:       result (str)
    Description:  Return a base string containing a subset of ASCII charactes
                  Defined base types:
                  lower, upper, alpha, lowernum, uppernum, alphanum, special, nonalpha, B6, BA, all
                      lower: lower case characters
                      upper: upper case characters
                      alpha: upper and lower case characters
                      lowernum: lower case and numerical characters
                      uppernum: upper case and numerical characters
                      alphanum: upper, lower and numerical characters
                      special: punctuations and special characters (no white space)
                      nonalpha: special and numerical characters
                      B6: num, lower, upper, space and newline
                      BA: upper + lower + num + special + ' \n'
                      all: upper, lower, numerical and special characters
    Errors:       if invalid base type, print error msg, return empty string
    ---------------------------------------------------
    """
    lower = "".join([chr(ord('a') + i) for i in range(26)])
    upper = lower.upper()
    num = "".join([str(i) for i in range(10)])
    special = ''
    for i in range(ord('!'), 127):
        if not chr(i).isalnum():
            special += chr(i)
            
    result = ''
    if base_type == 'lower':
        result = lower
    elif base_type == 'upper':
        result = upper
    elif base_type == 'alpha':
        result = upper + lower
    elif base_type == 'lowernum':
        result = lower + num
    elif base_type == 'uppernum':
        result = upper + num
    elif base_type == 'alphanum':
        result = upper + lower + num
    elif base_type == 'special':
        result = special
    elif base_type == 'nonalpha':
        result = special + num
    elif base_type == 'B6':  # 64 symbols
        result = num + lower + upper + ' ' + '\n'
    elif base_type == 'BA':  # 96 symbols
        result = upper + lower + num + special + ' \n'
    elif base_type == 'all':
        result = upper + lower + num + special
    else:
        print('Error(get_base): undefined base type')
        result = ''
    return result


'______________________________________________________________________________'


def get_language_freq(language='English'):
    """
    ----------------------------------------------------
    Parameters:   language (str): default = English 
    Return:       freq (list of floats) 
    Description:  Return frequencies of characters in a given language
                  Current implementation supports English language
                  If unsupported language --> print error msg and return []
    ---------------------------------------------------
    """
    if language == 'English':
        return [0.08167, 0.01492, 0.02782, 0.04253, 0.12702, 0.02228, 0.02015,
                0.06094, 0.06966, 0.00153, 0.00772, 0.04025, 0.02406, 0.06749,
                0.07507, 0.01929, 0.00095, 0.05987, 0.06327, 0.09056, 0.02758,
                0.00978, 0.0236, 0.0015, 0.01974, 0.00074]
    else:
        print('Error(get_language_freq): unsupported language')
        return []


def file_to_text(filename):
    """
    ----------------------------------------------------
    Parameters:   filename (str)
    Return:       contents (str)
    Description:  Utility function to read contents of a file
                  Can be used to read plaintext or ciphertext
    Asserts:      filename is a valid name
    ---------------------------------------------------
    """
    assert is_valid_filename(filename)
    
    with open(filename) as f:
        text = f.read()
    
    return text


def is_valid_filename(filename):
    """
    ----------------------------------------------------
    Parameters:   filename (str)
    Return:       True/False
    Description:  Checks if given input is a valid filename 
                  a filename should have at least 3 characters
                  and contains a single dot that is not the first or last character
    ---------------------------------------------------
    """
    ans = True
    
    if(len(filename) < 3):
        ans = False
    
    if(filename.count('.') != 1):
        ans = False
    
    if(filename[0] == "."):
        ans = False
        
    if(filename[len(filename) - 1] == "."):
        ans = False
    
    return ans


def get_positions(text, base):
    """
    ----------------------------------------------------
    Parameters:   text (str): input string
                  base (str):  stream of unique characters
    Return:       positions (2D list)
    Description:  Analyzes a given text for any occurrence of base characters
                  Returns a 2D list with characters and their respective positions
                  format: [[char1,pos1], [char2,pos2],...]
                  Example: get_positions('I have 3 cents.','c.h') -->
                      [['h',2],['c',9],['.',14]]
                  items are ordered based on their occurrence in the text
    Asserts:      text and base are strings
    ---------------------------------------------------
    """
    assert isinstance(text, str)
    assert isinstance(base, str)
    
    ans = []
    
    for i in range(len(text)):
        currentChar = text[i]
        if(currentChar in base):
            currentPos = [currentChar, i]
            ans.append(currentPos)

    return ans


def clean_text(text, base):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  base (str)
    Return:       updated_text (str)
    Description:  Constructs and returns a new text which has
                  all characters in original text after removing base characters
    Asserts:      text and base are strings
    ---------------------------------------------------
    """
    assert isinstance(text, str)
    assert isinstance(base, str)
    
    ans = ""
    
    for i in range(len(text)):
        currentChar = text[i]
        if(currentChar not in base):
            ans = ans + currentChar

    return ans


def insert_positions(text, positions):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  positions (list): [[char1,pos1],[char2,pos2],...]]
    Return:       updated_text (str)
    Description:  Inserts all characters in the positions 2D list (generated by get_positions)
                  into their respective locations
                  Assumes a valid positions 2d list is given
    Asserts:      text is a string and positions is a list
    ---------------------------------------------------
    """
    assert isinstance(text, str)
    assert isinstance(positions, list)
    
    ans = ""
    arr1 = []
    
    for i in range(len(text)):
        arr1.append(text[i])
    
    for j in range(len(positions)):
        currentChar = positions[j][0]
        currentIndex = positions[j][1]
        arr1.insert(currentIndex, currentChar)
    
    for k in range(len(arr1)):
        ans = ans + arr1[k]
        
    return ans


def shift_string(s, n, d='l'):
    """
    ----------------------------------------------------
    Parameters:   text (string): input string
                  shifts (int): number of shifts
                  direction (str): 'l' or 'r'
    Return:       update_text (str)
    Description:  Shift a given string by given number of shifts (circular shift)
                  If shifts is a negative value, direction is changed
                  If no direction is given or if it is not 'l' or 'r' set to 'l'
    Asserts:      text is a string and shifts is an integer
    ---------------------------------------------------
    """
    assert isinstance(s, str)
    assert isinstance(n, int)
    
    if(d == 'r'):
        n = n * (-1)
    
    shift = (n) % len(s)
    ans = s[shift: ] + s[: shift]
  
    return ans
