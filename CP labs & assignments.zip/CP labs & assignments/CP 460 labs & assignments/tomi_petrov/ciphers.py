"""
-----------------------------
Name: Tomi Petrov
ID: 180638460
-----------------------------
"""
import utilities, math

""" Add your cipher implementations in this file. Atbash is added for you"""


class Atbash:
    """
    ----------------------------------------------------
    Cipher name: Extended Atbash Cipher
    Key:         is base like: lower, upper, uppernum, special
    Type:        Substitution Cipher
    Description: An extended version of the original atbash cipher
                 The original Atbash uses the alphabet substituted by
                 its inverse order. The extended version uses different
                 bases (stream of alphabets) for substitution. 
                 Characters not defined in the base are not used in encryption
                 and decryption. 
    ----------------------------------------------------
    """
    BASE_TYPES = ['lower', 'upper', 'alpha', 'lowernum', 'uppernum', 'alphanum', 'special', 'all']
    DEFAULT_KEY = 'lower'
    
    def __init__(self, key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (str): the base (default value= 'lower')
        Description:  Atbash constructor
                      sets _key (atbash key)
        ---------------------------------------------------
        """
        self._key = self.DEFAULT_KEY
        if key != self.DEFAULT_KEY:
            self.set_key(key)
    
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key(str)
        Return:       success (bool): True/False
        Description:  Sets Atbash key to given key
                      The key should be one of the bases defined in BASE_TYPES
                      if invalid key, set it to default key
        ---------------------------------------------------
        """
        if Atbash.valid_key(key):
            self._key = key
            return True
        self._key = self.DEFAULT_KEY 
        return False
    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (str)
        Description:  Returns a copy of the Atbash key
        ---------------------------------------------------
        """
        return self._key
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Atbash key
        ---------------------------------------------------
        """
        return True if key in Atbash.BASE_TYPES else False
    
    def get_base(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       base (str)
        Description:  Returns the character stream defined by the key
        ---------------------------------------------------
        """
        return utilities.get_base(self._key)
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of the Atbash object
                      output format:
                      Extended Atbash Cipher:
                      key = <key>
                      <base>
                      <reverse of base>
        ---------------------------------------------------
        """
        base = self.get_base()
        base_rev = base[::-1]
        output = 'Extend Atbash Cipher:\n'
        output += 'key = {}\n'.format(self._key)
        for c in base:
            output += '{} '.format(c)
        output = output[:-1] + '\n'  # remove last space, add new line
        for c in base_rev:
            output += '{} '.format(c)
        return output[:-1]

    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext(str)
        Return:       ciphertext (str)
        Description:  Encryption using Extended Atbash Cipher
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        assert type(plaintext) == str, 'invalid plaintext'
        base = self.get_base()
        base_rev = base[::-1]
        ciphertext = ''
        for plainchar in plaintext:
            if plainchar in base:
                cipherchar = base_rev[base.index(plainchar)]
                ciphertext += cipherchar
            else:
                ciphertext += plainchar
        return ciphertext

    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext(str)
        Return:       plaintext (str)
        Description:  Decryption using Atbash Cipher
        Asserts:      ciphertext is a string
        ----------------------------------------------------
        """
        assert type(ciphertext) == str, 'invalid ciphertext'
        # Decryption can be achieved by encrypting ciphertext!!
        return self.encrypt(ciphertext)

    @staticmethod
    def cryptanalyze(ciphertext, args=[None, 0.8]):
        """
        ----------------------------------------------------
        Parameters:   ciphertext(str)
                      args (list):
                          dictionary_file (str): default = None
                          threshold (float): default = 0.8
        Return:       key (str): base type
                      plaintext (str)
        Description:  Cryptanalysis of Extended Atbash Cipher
                      Key is a base type
                      Assumes user passes a valid args
        Asserts:      ciphertext is a string
        ----------------------------------------------------
        """
        assert type(ciphertext) == str, 'invalid ciphertext'
        
        # extract arguments
        dictionary_file, threshold = args        
        dict_list = utilities.load_dictionary(dictionary_file)
        
        found = False
        atbash = Atbash()
        for i in range(len(Atbash.BASE_TYPES)):
            atbash.set_key(Atbash.BASE_TYPES[i])
            plaintext = atbash.decrypt(ciphertext)
            if utilities.is_plaintext(plaintext, dict_list, threshold):
                key = Atbash.BASE_TYPES[i]
                found = True
                break
            
        if not found:
            print('Atbash.cryptanalyze: cryptanalysis failed')
            return '', ''
        
        return key, plaintext

    
class Polybius:
    """
    ----------------------------------------------------
    Cipher name: Polybius Square Cipher (205-123 BC)
    Key:         tuple(start_char,size)
    Type:        Substitution Cipher
    Description: Substitutes every character with two digit number [row#][column#]
                 Implementation allows different square sizes with customized start ASCII char
                 Default square is 5x5 starting at 'a' and ending in 'y' (z not encrypted)
                 Encrypts/decrypts only characters defined in the square
    ----------------------------------------------------
    """
    
    DEFAULT_KEY = ('a', 5)

    def __init__(self, key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (str): default = ('a',5)
        Description:  Polybius Cipher constructor
                      sets _key
        ---------------------------------------------------
        """
        Polybius.set_key(self, key)

    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Returns:      key (tuple)
        Description:  Returns a copy of current key
        ---------------------------------------------------
        """
        return self.key
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?): an arbitrary input
        Returns:      True/False
        Description:  Check if given input is a valid Polybius key
                      A valid key is a tuple with two elements
                      First element (start_char) is a single ASCII character
                      Second element (size) is an integer
                      The start_char should be an ASCII value between space and ~
                      The size should be an integer in the range [2,9]
                      The combination of start_char and size should not result in
                      a string that is beyond the ASCII range of [' ', '~']
        ---------------------------------------------------
        """
        ans = True

        if(isinstance(key, tuple) == False or len(key) != 2):
            ans = False
            
        elif(isinstance(key[1], int) and isinstance(key[0], str) and len(key[0]) == 1):
            var1 = ord(key[0])
            var2 = key[1] * key[1]
        
        else:
            ans = False
            
        if(ans == True):
            if(ord(key[0]) < 32 or ord(key[0]) > 126):
                ans = False
                
            elif(key[1] < 2 or key[1] > 9):
                ans = False
            
            elif(var1 + var2 > 127):
                ans = False
        
        return ans
    
    def get_square(self, mode='list'):
        """
        ----------------------------------------------------
        Parameters:   mode(str)= 'list' or 'string'
        Returns:      square (2D list)
        Description:  Constructs Polybius square from key
                      Square can be returned as a 2D list or
                      as a string formatted as a matrix
        Errors:       if mode is not 'list' or 'string'
                          print error_msg: 'Error(Polybius.get_square): undefined mode'
                          return empty string
        ---------------------------------------------------
        """
        ans = ""
        if(mode == "list"):
            ans = [[0] * self.key[1] for i in range(self.key[1])]
            
            for i in range(self.key[1]):
                for j in range(self.key[1]):
                    currentChar = chr(ord(self.key[0]) + (i * self.key[1]) + j)
                    ans[i][j] = currentChar
        
        elif(mode == "string"): 
            for i in range(self.key[1]):
                for j in range(self.key[1]):
                    currentChar = chr(ord(self.key[0]) + (i * self.key[1]) + j)
                    ans = ans + currentChar
                    ans = ans + "  "
                    if(j == self.key[1] - 1 and i != self.key[1] - 1):
                        ans = ans + "\n"
            
        else:
            print("Error(Polybius.get_square): undefined mode")
        
        return ans
        
    def _get_base(self):
        """
        ----------------------------------------------------
        A private helper function that returns the characters defined
        in the Polybius square as a single string
        String begins with start_char and ends with key*key subsequent chars
        ---------------------------------------------------
        """
        ans = ""
        var = self.key[1] * self.key[1]
        for i in range(var):
            currentChar = chr(ord(self.key[0]) + i)
            ans = ans + currentChar
            
        return ans
    
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (tuple)
        Returns:      success (True/False)
        Description:  Sets Polybius object key to given key
                      Does not update key if invalid key
                      Returns success status: True/False
        ---------------------------------------------------
        """
        ans = True
        if(Polybius.valid_key(key)):
            self.key = key
            
        else:
            ans = False
        
        return ans
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str): string representation
        Description:  Returns a string representation of polybius
                      Format:
                      Polybius Cipher:
                      key = <key>
                      <polybius_square in matrix format>
        ---------------------------------------------------
        """
        ans = ""
        begin = "Polybius Cipher:" + "\n"
        mid = "key = {}".format(self.key) + "\n"
        end = Polybius.get_square(self, "string")
        ans = begin + mid + end
        
        return ans
    
    def encode(self, plainchar):
        """
        -------------------------------------------------------
        Parameters:   plainchar(str): single character
        Return:       cipher(str): two digit number
        Description:  Substitutes a character with corresponding two numbers
                          using the defined Polybius square
                      If character is not defined in square return ''
        Errors:       if input is not a single character --> 
                         msg: 'Error(Polybius.encode): invalid input'
                         return empty string
        -------------------------------------------------------
        """
        ans = ""
        if(isinstance(plainchar, str) == False or len(plainchar) != 1):
            print("Error(Polybius.encode): invalid input")
        
        else:
            matrix = Polybius.get_square(self)
            for i in range(len(matrix)):
                for j in range(len(matrix[0])):
                    if (matrix[i][j] == plainchar):
                        ans = str(i + 1) + str(j + 1)
                
        return ans

    def decode(self, cipher):
        """
        -------------------------------------------------------
        Parameters:   cipher(str): two digit number
        Return:       plainchar(str): a single character
        Description:  Substitutes a two digit number with a corresponding char
                          using the defined Polybius square
                      If invalid two digit number return empty string
        Errors:       if input is not string composing of two digits  --> 
                         msg: 'Error(Polybius.decode): invalid input'
                         return empty string
        -------------------------------------------------------
        """
        ans = ""
        if(cipher.isnumeric() == False or isinstance(cipher, str) == False or len(cipher) != 2):
            print("Error(Polybius.decode): invalid input")
            
        else:
            matrix = Polybius.get_square(self)
            first = int(cipher[0]) - 1
            second = int(cipher[1]) - 1
            for i in range(len(matrix)):
                for j in range(len(matrix[0])):
                    if (i == first and j == second):
                        ans = matrix[i][j]
            
        return ans
    
    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (list)
        Description:  Encryption using Polybius cipher
                      Encrypts only characters defined in the square
        Asserts:      plaintext is a string
        ----------------------------------------------------
        """
        assert isinstance(plaintext, str)
        
        ans = ""
        for i in range(len(plaintext)):
            current = Polybius.encode(self, plaintext[i])
            
            if(current != ""):
                ans = ans + current
                
            else:
                ans = ans + plaintext[i]
        
        return ans

    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (list)
        Description:  decryption using Polybius cipher
                        decrypts only 2 digit numbers
        Asserts:      ciphertext is a string
        ----------------------------------------------------
        """
        assert isinstance(ciphertext, str)
        
        ans = ""
        keepgoing = False
        mem = ""
        for i in range(len(ciphertext)):
            if(ciphertext[i].isnumeric() == False and keepgoing == False):
                ans = ans + ciphertext[i]
                keepgoing = False
                mem = ""
            
            elif(ciphertext[i].isnumeric() == False and keepgoing == True):
                ans = ans + mem + ciphertext[i]
                keepgoing = False
                mem = ""
            
            elif(ciphertext[i].isnumeric() == True and keepgoing == False):
                mem = ciphertext[i]
                keepgoing = True
                if(i == len(ciphertext) - 1):
                    ans = ans + ciphertext[i]
                
            elif(ciphertext[i].isnumeric() == True and keepgoing == True):
                finVal = mem + ciphertext[i]
                addTo = Polybius.decode(self, finVal)
                ans = ans + addTo
                mem = ""
                keepgoing = False
                
        return ans
    
    
class Vigenere:
    """
    ----------------------------------------------------
    Cipher name: Vigenere Cipher
    Key:         (str): a character or a keyword
    Type:        Polyalphabetic Substitution Cipher
    Description: if key is a single characters, uses autokey method
                    Otherwise, it uses a running key
                 In autokey: key = autokey + plaintext (except last char)
                 In running key: repeat the key
                 Substitutes only alpha characters (both upper and lower)
                 Preserves the case of characters
    ----------------------------------------------------
    """
    
    DEFAULT_KEY = 'k'
    
    def __init__(self, key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (str): default value: 'k'
        Description:  Vigenere constructor
                      sets _key
                      if invalid key, set to default key
        ---------------------------------------------------
        """
        self.key = key
    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (str)
        Description:  Returns a copy of the Vigenere key
        ---------------------------------------------------
        """
        return self.key
       
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (str): non-empty string
        Return:       success: True/False
        Description:  Sets Vigenere cipher key to given key
                      All non-alpha characters are removed from the key
                      key is converted to lower case
                      if invalid key --> set to default key
        ---------------------------------------------------
        """ 
        ans = False
        
        cBase = utilities.get_base("lower")
        newKey = ""
        
        if(Vigenere.valid_key(key)):
            key = utilities.clean_text(key, ' \n')
            key = key.lower()
            
            for i in range(len(key)):
                if(cBase.find(key[i]) != -1):
                    newKey = newKey + key[i]
                
            self.key = newKey
            ans = True
            
        else:
            self.key = Vigenere.DEFAULT_KEY
            
        return ans
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Vigenere object. Used for testing
                      output format:
                      Vigenere Cipher:
                      key = <key>
        ---------------------------------------------------
        """
        ans = "Vigenere Cipher:"
        ans = ans + "\n"
        ans = ans + "key = {}".format(self.key)
        
        return ans
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Vigenere key
                      A valid key is a string composing of at least one alpha char
        ---------------------------------------------------
        """
        ans = False
        cBase = utilities.get_base("alpha")
        
        for i in range(len(key)):
            if(cBase.find(key[i]) != -1):
                ans = True
        
        return ans

    @staticmethod
    def get_square():
        """
        ----------------------------------------------------
        static method
        Parameters:   -
        Return:       vigenere_square (list of string)
        Description:  Constructs and returns vigenere square
                      The square contains a list of strings
                      element 1 = "abcde...xyz"
                      element 2 = "bcde...xyza" (1 shift to left)
        ---------------------------------------------------
        """
        ans = []
        cBase = utilities.get_base("lower")
        for i in range(len(cBase)):
            cSub = utilities.shift_string(cBase, i, "l")
            ans.append(cSub)

        return ans

    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Vigenere Cipher
                      May use an auto character or a running key
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        assert type(plaintext) == str, 'invalid plaintext'
        
        if len(self.key) == 1:
            return self._encrypt_auto(plaintext)
        else:
            return self._encrypt_run(plaintext)

    def _encrypt_auto(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Private helper function
                      Encryption using Vigenere Cipher Using an autokey
        ---------------------------------------------------
        """
        special = utilities.get_base("nonalpha")
        test1 = utilities.get_positions(plaintext, special + " " + '\n')
        plaintext = utilities.clean_text(plaintext, special + " " + '\n')
        
        ans = ""
        newKey = ""
        
        numRep = int(math.ceil(len(plaintext) / len(self.key)))
        for i in range(numRep):
            newKey = newKey + self.key
        
        table = Vigenere.get_square()
        
        for i in range(len(plaintext)):
            newKeyValue = ord(newKey[i]) - 97
            
            if(plaintext[i].islower()):
                currVal = ord(plaintext[i]) - 97
                finVal = table[newKeyValue][currVal]
                
            else:
                currVal = ord(plaintext[i]) - 65
                finVal = table[newKeyValue][currVal]
                finVal = finVal.upper()
            
            ans = ans + finVal
                
        ans = utilities.insert_positions(ans, test1)
        
        return ans

    def _encrypt_run(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Private helper function
                      Encryption using Vigenere Cipher Using a running key
        ---------------------------------------------------
        """
        special = utilities.get_base("nonalpha")
        test1 = utilities.get_positions(plaintext, special + " " + '\n')
        plaintext = utilities.clean_text(plaintext, special + " " + '\n')
        
        ans = ""
        newKey = ""
        
        numRep = int(math.ceil(len(plaintext) / len(self.key)))
        for i in range(numRep):
            newKey = newKey + self.key
        
        table = Vigenere.get_square()
        
        for i in range(len(plaintext)):
            newKeyValue = ord(newKey[i]) - 97
            
            if(plaintext[i].islower()):
                currVal = ord(plaintext[i]) - 97
                finVal = table[newKeyValue][currVal]
                
            else:
                currVal = ord(plaintext[i]) - 65
                finVal = table[newKeyValue][currVal]
                finVal = finVal.upper()
            
            ans = ans + finVal
                
        ans = utilities.insert_positions(ans, test1)
        
        return ans

    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Vigenere Cipher
                      May use an auto character or a running key
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """
        assert type(ciphertext) == str, 'invalid input'
        
        if len(self.key) == 1:
            return self._decryption_auto(ciphertext)
        else:
            return self._decryption_run(ciphertext)

    def _decryption_auto(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Private Helper method
                      Decryption using Vigenere Cipher Using autokey
        ---------------------------------------------------
        """
        special = utilities.get_base("nonalpha")
        test1 = utilities.get_positions(ciphertext, special + " " + '\n')
        ciphertext = utilities.clean_text(ciphertext, special + " " + '\n')
        
        ans = ""
        newKey = ""
        
        numRep = int(math.ceil(len(ciphertext) / len(self.key)))
        for i in range(numRep):
            newKey = newKey + self.key
        
        table = Vigenere.get_square()
        
        for i in range(len(ciphertext)):
            newKeyValue = ord(newKey[i]) - 97
            
            if(ciphertext[i].islower()):
                currVal = table[newKeyValue].find(ciphertext[i])
                finVal = table[0][currVal]
                
            else:
                currVal = table[newKeyValue].find(ciphertext[i].lower())
                finVal = table[0][currVal]
                finVal = finVal.upper()
            
            ans = ans + finVal
                
        ans = utilities.insert_positions(ans, test1)
        
        return ans

    def _decryption_run(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Private Helper method
                      Decryption using Vigenere Cipher Using running key
        ---------------------------------------------------
        """
        special = utilities.get_base("nonalpha")
        test1 = utilities.get_positions(ciphertext, special + " " + '\n')
        ciphertext = utilities.clean_text(ciphertext, special + " " + '\n')
        
        ans = ""
        newKey = ""
        
        numRep = int(math.ceil(len(ciphertext) / len(self.key)))
        for i in range(numRep):
            newKey = newKey + self.key
        
        table = Vigenere.get_square()
        
        for i in range(len(ciphertext)):
            newKeyValue = ord(newKey[i]) - 97
            
            if(ciphertext[i].islower()):
                currVal = table[newKeyValue].find(ciphertext[i])
                finVal = table[0][currVal]
                
            else:
                currVal = table[newKeyValue].find(ciphertext[i].lower())
                finVal = table[0][currVal]
                finVal = finVal.upper()
            
            ans = ans + finVal
                
        ans = utilities.insert_positions(ans, test1)
        
        return ans
    
    
class Columnar_Transposition:
    """
    ----------------------------------------------------
    Cipher name: Columnar Transposition Cipher
    Key:         (str) a keyword
    Type:        Transposition Cipher
    Description: Constructs a table from plaintext, 
                 #columns = len(keyword)
                 Rearrange columns based on keyword order
                 Read the text vertically
                 Applies to all characters except whitespaces
    ----------------------------------------------------
    """
    
    DEFAULT_PAD = 'q'
    DEFAULT_PASSWORD = 'abcd'
    
    def __init__(self, key=DEFAULT_PASSWORD, pad=DEFAULT_PAD):
        """
        ----------------------------------------------------
        Parameters:   _key (str): default = abcd
                      _pad (str): a character, default = q
        Description:  Columnar Transposition constructor
                      sets _key and _pad
        ---------------------------------------------------
        """
        Columnar_Transposition.set_key(self, key)
        Columnar_Transposition.set_pad(self, pad)
            
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (str)
        Description:  Returns a copy of columnar transposition key
        ---------------------------------------------------
        """
        return self.key
    
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (str): keyword
        Return:       success: True/False
        Description:  Sets key to given key
                      if invalid key --> set to default key
        ---------------------------------------------------
        """
        ans = True
        if(Columnar_Transposition.valid_key(key)):
            self.key = key
            
        else:
            self.key = Columnar_Transposition.DEFAULT_PASSWORD
            ans = False
        
        return ans
        
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Columnar Transposition object
                      output format:
                      Columnar Transposition Cipher:
                      key = <key>, pad = <pad>
        ---------------------------------------------------
        """
        ans = "key = {}, pad = {}".format(self.key, self.pad)
        return ans
        
    def get_pad(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       pad (str): current padding character
        Description:  Returns a copy of current padding character
        ---------------------------------------------------
        """ 
        return self.pad
    
    def set_pad(self, pad):
        """
        ----------------------------------------------------
        Parameters:   pad (str): a padding character
        Return:       success: True/False
        Description:  Sets pad to given character
                      a pad should be a single character
                      if invalid pad, set to default value
        ---------------------------------------------------
        """ 
        ans = True
        
        if(isinstance(pad, str)):
            if(len(pad) == 1):
                self.pad = pad
                
            else:
                self.pad = Columnar_Transposition.DEFAULT_PAD
                ans = False
                
        else:
            ans = False
        
        return ans

    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?): an arbitrary input
        Returns:      True/False
        Description:  Check if given input is a valid Columnar Transposition key
                      A valid key is a string consisting of at least two unique chars
        ---------------------------------------------------
        """
        ans = True
        base = ' ' + utilities.get_base('all')
        
        if(isinstance(key, str)):
            key = "".join(dict.fromkeys(key))
            
            valid = True
            if(len(key) >= 2):
                for i in range(len(key)):
                    if(base.find(key[i]) == -1):
                        valid = False
                        
            else:
                ans = False
                
            if(valid == False):
                ans = False
        
        else:
            ans = False
        
        return ans
 
    @staticmethod
    def key_order(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (str)           
        Return:       key_order (list)
        Description:  Returns key order
                      Example: [mark] --> akmr --> [1,3,0,2]
                      If invalid key --> return []
                      Applies to all ASCII characters from space to ~
                      Discards duplicate characters
        ----------------------------------------------------
        """  
        key = "".join(dict.fromkeys(key))
        
        base = ' ' + utilities.get_base('all')
        
        valid = True
        arr1 = []
        arr2 = []
        keylen = len(key)
        for i in range(keylen):
            if(base.find(key[i]) != -1):
                arr1.append(base.find(key[i]))
            else:
                valid = False
        if(valid == True):
            arr2 = sorted(range(len(arr1)), key=arr1.__getitem__)
        
        return arr2
        
    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (list)
        Description:  Encryption using Columnar Transposition Cipher
                      Does not include whitespaces in encryption
                      Uses padding
        Asserts:      plaintext is a string
        ----------------------------------------------------
        """
        assert isinstance(plaintext, str)
        
        test1 = utilities.get_positions(plaintext, ' \n')
        plaintext = utilities.clean_text(plaintext, ' \n')
        
        self.key = "".join(dict.fromkeys(self.key))
        
        ans = ""
        key_order = Columnar_Transposition.key_order(self.key)
        plaintext2 = list(plaintext)
        col = len(self.key)
        row = int(math.ceil(len(plaintext) / col))
  
        padding = int((row * col) - len(plaintext))
        plaintext2.extend(self.pad * padding)
        
        initalArray = [plaintext2[i: i + col] 
        for i in range(0, len(plaintext2), col)]
                
        for i in range(len(initalArray[0])):
            current = key_order[i]
            for j in range(len(initalArray)):
                ans = ans + initalArray[j][current]
        
        ans = utilities.insert_positions(ans, test1)
        
        return ans
        
    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (list)
        Description:  Decryption using Columnar Transposition Cipher
        Asserts:      ciphertext is a string
        ----------------------------------------------------
        """
        assert isinstance(ciphertext, str)
        
        test1 = utilities.get_positions(ciphertext, ' \n')
        ciphertext = utilities.clean_text(ciphertext, ' \n')
        
        self.key = "".join(dict.fromkeys(self.key))
        
        key_order = Columnar_Transposition.key_order(self.key)
        plaintext2 = list(ciphertext)
        col = len(self.key)
        row = int(math.ceil(len(ciphertext) / col))
        ans = [[0] * col for i in range(row)]
        final = ""
        
        initalArray = [plaintext2[i: i + row] 
        for i in range(0, len(plaintext2), row)]
                
        for i in range(len(initalArray)):
            current = key_order[i]
            for j in range(len(initalArray[0])):
                ans[j][current] = initalArray[i][j]
        
        for i in range(len(ans)):
            for j in range(len(ans[0])):
                final = final + ans[i][j]
                
        final = utilities.insert_positions(final, test1)
        
        while(final[len(final) - 1] == self.pad):
            final = final[:-1]
        
        return final

    
class Simple_Substitution:
    """
    ----------------------------------------------------
    Cipher name: Simple Substitution Cipher
    Key:         tuple(keyword(str),base(str))
    Type:        Substitution Cipher
    Description: The base is a stream of unique characters
                 Only characters defined in the base are substituted
                 The base is case insensitive
                 The keyword is a random arrangement of the base, or some of its characters
                 The substitution string is the keyword, then all base characters
                     not in keyword, while maintaining their order in the base
                 The case of characters should be preserved whenever possible
    ----------------------------------------------------
    """
    DEFAULT_KEY = ('frozen', 'abcdefghijklmnopqrstuvwxyz')

    def __init__(self, key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (str)
        Description:  Simple Substitution Cipher constructor
                      sets _key
        ---------------------------------------------------
        """
        self.key = key

    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Returns:      key (tuple)
        Description:  Returns a copy of current key
        ---------------------------------------------------
        """
        return self.key
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?): an arbitrary input
        Returns:      True/False
        Description:  Check if given input is a valid Simple Substitution key
                      The key is a tuple composing of two strings
                      The base should contain at least two unique characters
                      The keyword should have at least two unique characters defined in the base
        ---------------------------------------------------
        """
        ans = True
        
        if(isinstance(key, tuple) and len(key) == 2):
            key = list(key)
            key[0] = "".join(dict.fromkeys(key[0]))
            key[1] = "".join(dict.fromkeys(key[1]))
            key[0] = key[0].lower()
            key[1] = key[1].lower()
            abc = "".join(sorted(set(key[0]).intersection(set(key[1]))))
            key = tuple(key)
        
        if(isinstance(key, tuple) == False or len(key) != 2):
            ans = False
            
        elif(isinstance(key[0], str) == False or len(key[0]) < 2):
            ans = False
            
        elif(isinstance(key[1], str) == False or len(key[1]) < 2):
            ans = False            
        
        elif(len(abc) < 2):
            ans = False
        
        return ans
    
    def get_table(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Returns:      [base,sub]
        Description:  Constructs a substitution table
                      First element is the base string
                      Second element is the substitution string 
        ---------------------------------------------------
        """
        final = []
        key = list(self.key)
        ans = key[0] + key[1]
        ans = "".join(dict.fromkeys(ans))
        final.append(self.key[0])
        final.append(ans)
        return final
    
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (tuple(str,str))
        Returns:      success (True/False)
        Description:  Sets Simple Substitution key to given key
                      Does not update key if invalid key
                      Stores key without duplicates in lower case
                          duplicates in base are removed
                          duplicates in keyword are removed
                          keyword chars not in base are removed
                      Returns success status: True/False
        ---------------------------------------------------
        """
        ans = True
        check = Simple_Substitution.valid_key(key)
        key = list(key)
        
        if(check == True):
            key[0] = "".join(dict.fromkeys(key[0]))
            key[1] = "".join(dict.fromkeys(key[1]))
            key[0] = ''.join(sorted(set(key[1]).intersection(set(key[0]))))
            
            key = tuple(key)
            self.key = key

        else:
            ans = False
    
        return ans
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str): string representation
        Description:  Returns a string representation of Simple Substitution
                      Format:
                      Simple Substitution Cipher:
                      keyword = <keyword>
                      <base string>
                      <sub string>
        ---------------------------------------------------
        """
        table = Simple_Substitution.get_table(self)
        
        ans = ""
        ans = ans + "Simple Substitution Cipher:" + "\n"
        ans = ans + "keyword = {}".format(self.key[0]) + "\n"
        ans = ans + self.key[1] + "\n"
        ans = ans + table[1]
        return ans
    
    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (list)
        Description:  Encryption using Simple Substitution Cipher
                      Encrypts only characters defined in base
                      Preserves the case of characters
        Asserts:      plaintext is a string
        ----------------------------------------------------
        """
        special = utilities.get_base("nonalpha")
        test1 = utilities.get_positions(plaintext, special + " " + '\n')
        plaintext = utilities.clean_text(plaintext, special + " " + '\n')
        
        table = Simple_Substitution.get_table(self)
        ans = ""
        
        for i in range(len(plaintext)):
            if(plaintext[i].islower()):
                index = table[0].find(plaintext[i])
                ans = ans + table[1][index]
            
            else:
                newChar = plaintext[i].lower()
                index = table[0].find(newChar)
                ans = ans + table[1][index].upper()
            
        ans = utilities.insert_positions(ans, test1)
        
        return ans

    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (list)
        Description:  decryption using Simple Substitution Cipher
                      Decrypts only characters defined in base
                      Preserves the case of characters
        Asserts:      ciphertext is a string
        ----------------------------------------------------
        """
        special = utilities.get_base("nonalpha")
        test1 = utilities.get_positions(ciphertext, special + " " + '\n')
        ciphertext = utilities.clean_text(ciphertext, special + " " + '\n')
        
        table = Simple_Substitution.get_table(self)
        ans = ""
        
        for i in range(len(ciphertext)):
            if(ciphertext[i].islower()):
                index = table[1].find(ciphertext[i])
                ans = ans + table[0][index]
            
            else:
                newChar = ciphertext[i].lower()
                index = table[1].find(newChar)
                ans = ans + table[0][index].upper()
            
        ans = utilities.insert_positions(ans, test1)
        
        return ans


class Shift:
    """
    ----------------------------------------------------
    Cipher name: Shift Cipher
    Key:         (int,int,int): shifts,start_index,end_index
    Type:        Shift Substitution Cipher
    Description: Generalized version of Caesar cipher
                 Uses a subset of BASE for substitution table
                 Shift base by key and then substitutes
                 Case sensitive
                 Preserves the case whenever possible
                 Uses circular left shift
    ----------------------------------------------------
    """
    BASE = utilities.get_base('all') + ' '
    DEFAULT_KEY = (3, 26, 51)  # lower case Caesar cipher
    
    def __init__(self, key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (int,int,int): 
                        #shifts, start_index, end_indx 
                        (inclusive both ends of indices)
        Description:  Shift constructor
                      sets _key
        ---------------------------------------------------
        """
        self.key = key
    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (str)
        Description:  Returns a copy of the Shift key
        ---------------------------------------------------
        """
        return self.key
       
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (str): non-empty string
        Return:       success: True/False
        Description:  Sets Shift cipher key to given key
                      #shifts is set to smallest value
                      if invalid key --> set to default key
        ---------------------------------------------------
        """ 
        ans = False
        
        if(Shift.valid_key(key)):
            key = list(key)
            if(key[0] < 0):
                key[0] = key[0] + 77
            
            self.key = key
            ans = True
            
        else:
            self.key = Shift.DEFAULT_KEY
        
        return ans

    def get_base(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       base (str)
        Description:  Returns a copy of the base characters
                      base is the subset of characters from BASE
                      starting at start_index and ending with end_index
                      (inclusive both ends)
        ---------------------------------------------------
        """
        ans = ""
        inital = Shift.BASE
        
        for i in range(self.key[1], self.key[2] + 1):
            if(i < 95):
                ans = ans + inital[i]
        
        return ans
        
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Shift object. Used for testing
                      output format:
                      Shift Cipher:
                      key = <key>
                      base = <base>
                      sub  = <sub>
        ---------------------------------------------------
        """
        cBase = Shift.get_base(self)
        cSub = utilities.shift_string(cBase, self.key[0], "l")
        
        ans = "Shift Cipher:"
        ans = ans + "\n"
        ans = ans + "key = {}".format(self.key)
        ans = ans + "\n"
        ans = ans + "base = {}".format(cBase)
        ans = ans + "\n"
        ans = ans + "sub  = {}".format(cSub)
        
        return ans
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Shift key
                      A valid key is a tuple consisting of three integers
                          shifts, start_index, end_index
                      The shifts can be any integer
                      The start and end index should be positive values
                      such that start is smaller than end and both are within BASE
        ---------------------------------------------------
        """
        ans = True
        
        if(isinstance(key, tuple) == False or len(key) != 3):
            ans = False
            
        elif(isinstance(key[0], int) == False or isinstance(key[1], int) == False or isinstance(key[2], int) == False):
            ans = False
            
        elif(key[1] < 0 or key[2] < 0):
            ans = False
            
        elif(key[1] >= key[2] or key[2] > len(Shift.BASE)):
            ans = False
        
        return ans

    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Shift Cipher
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        assert isinstance(plaintext, str)
        
        test1 = utilities.get_positions(plaintext, ' \n')
        plaintext = utilities.clean_text(plaintext, ' \n')
        
        ans = ""
        
        cBase = Shift.get_base(self)
        cSub = utilities.shift_string(cBase, self.key[0], "l")
        
        for i in range(len(plaintext)):
            cIndex = cBase.find(plaintext[i])
            
            if(cIndex == -1):
                cReplace = plaintext[i]
            
            else: 
                cReplace = cSub[cIndex]
                
            ans = ans + cReplace
        
        ans = utilities.insert_positions(ans, test1)

        return ans

    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Shift Cipher
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """
        assert isinstance(ciphertext, str)
        
        test1 = utilities.get_positions(ciphertext, ' \n')
        ciphertext = utilities.clean_text(ciphertext, ' \n')
        
        ans = ""
        
        cBase = Shift.get_base(self)
        cSub = utilities.shift_string(cBase, self.key[0], "r")
        
        for i in range(len(ciphertext)):
            cIndex = cBase.find(ciphertext[i])
            
            if(cIndex == -1):
                cReplace = ciphertext[i]
            
            else: 
                cReplace = cSub[cIndex]
                
            ans = ans + cReplace
        
        ans = utilities.insert_positions(ans, test1)

        return ans
