"""
-----------------------------
CP460 (Fall 2021)
Name: Tomi Petrov
ID: 180638460
Assignment 1
-----------------------------
"""
"""Put any comments to the grader here"""

from fileinput import filename
from pickle import TRUE, FALSE

DICT_FILE = 'engmix.txt'
PAD = 'q'

'______________________________________________________________________________'


def get_base(base_type):
    """
    ----------------------------------------------------
    Parameters:   base_type (str) 
    Return:       result (str)
    Description:  Return a base string containing a subset of ASCII charactes
                  Defined base types:
                  lower, upper, alpha, lowernum, uppernum, alphanum, special, nonalpha, B6, BA, all
                      lower: lower case characters
                      upper: upper case characters
                      alpha: upper and lower case characters
                      lowernum: lower case and numerical characters
                      uppernum: upper case and numerical characters
                      alphanum: upper, lower and numerical characters
                      special: punctuations and special characters (no white space)
                      nonalpha: special and numerical characters
                      B6: num, lower, upper, space and newline
                      BA: upper + lower + num + special + ' \n'
                      all: upper, lower, numerical and special characters
    Errors:       if invalid base type, print error msg, return empty string
    ---------------------------------------------------
    """
    lower = "".join([chr(ord('a') + i) for i in range(26)])
    upper = lower.upper()
    num = "".join([str(i) for i in range(10)])
    special = ''
    for i in range(ord('!'), 127):
        if not chr(i).isalnum():
            special += chr(i)
            
    result = ''
    if base_type == 'lower':
        result = lower
    elif base_type == 'upper':
        result = upper
    elif base_type == 'alpha':
        result = upper + lower
    elif base_type == 'lowernum':
        result = lower + num
    elif base_type == 'uppernum':
        result = upper + num
    elif base_type == 'alphanum':
        result = upper + lower + num
    elif base_type == 'special':
        result = special
    elif base_type == 'nonalpha':
        result = special + num
    elif base_type == 'B6':  # 64 symbols
        result = num + lower + upper + ' ' + '\n'
    elif base_type == 'BA':  # 96 symbols
        result = upper + lower + num + special + ' \n'
    elif base_type == 'all':
        result = upper + lower + num + special
    else:
        print('Error(get_base): undefined base type')
        result = ''
    return result


'______________________________________________________________________________'


def get_language_freq(language='English'):
    """
    ----------------------------------------------------
    Parameters:   language (str): default = English 
    Return:       freq (list of floats) 
    Description:  Return frequencies of characters in a given language
                  Current implementation supports English language
                  If unsupported language --> print error msg and return []
    ---------------------------------------------------
    """
    if language == 'English':
        return [0.08167, 0.01492, 0.02782, 0.04253, 0.12702, 0.02228, 0.02015,
                0.06094, 0.06966, 0.00153, 0.00772, 0.04025, 0.02406, 0.06749,
                0.07507, 0.01929, 0.00095, 0.05987, 0.06327, 0.09056, 0.02758,
                0.00978, 0.0236, 0.0015, 0.01974, 0.00074]
    else:
        print('Error(get_language_freq): unsupported language')
        return []

    
'______________________________________________________________________________'


def file_to_text(filename):
    """
    ----------------------------------------------------
    Parameters:   filename (str)
    Return:       contents (str)
    Description:  Utility function to read contents of a file
                  Can be used to read plaintext or ciphertext
    Asserts:      filename is a valid name
    ---------------------------------------------------
    """
    assert is_valid_filename(filename)
    
    with open(filename) as f:
        text = f.read()
    
    return text


'______________________________________________________________________________'


def text_to_file(text, filename):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  filename (str)            
    Return:       no returns
    Description:  Utility function to write any given text to a file
                  If file already exist, previous contents will be erased
    Asserts:      text is a string and filename is a valid filename
    ---------------------------------------------------
    """
    assert is_valid_filename(filename)
    assert isinstance(text, str)

    f = open(filename, "w")
    f.write(text)
    f.close()

    return


'______________________________________________________________________________'


def is_valid_filename(filename):
    """
    ----------------------------------------------------
    Parameters:   filename (str)
    Return:       True/False
    Description:  Checks if given input is a valid filename 
                  a filename should have at least 3 characters
                  and contains a single dot that is not the first or last character
    ---------------------------------------------------
    """
    ans = True
    
    if(len(filename) < 3):
        ans = False
    
    if(filename.count('.') != 1):
        ans = False
    
    if(filename[0] == "."):
        ans = False
        
    if(filename[len(filename) - 1] == "."):
        ans = False
    
    return ans


'______________________________________________________________________________'

   
def load_dictionary(dict_file=None):
    """
    ----------------------------------------------------
    Parameters:   dict_file (str): filename
                        default value = None
    Return:       dict_list (list): 2D list
    Description:  Reads a given dictionary file
                  dictionary is assumed to be formatted as each word in a separate line
                  Returns a list of lists, list 0 contains all words starting with 'a'
                  list 1 all words starting with 'b' and so forth.
                  if no parameter given, use default file (DICT_FILE)
    Errors:       if invalid filename, print error msg, return []
    ---------------------------------------------------
    """
    ans = []
    
    if(is_valid_filename(dict_file)):
        with open(dict_file, encoding="ISO-8859-15") as f:
            lines = f.readlines()

        for _ in range(26):
            ans.append([])
        
        for i in range(len(lines)):
            currentWord = lines[i]
            currentAscii = ord(currentWord[0]) - 97
            ans[currentAscii].append(currentWord.rstrip())
            
    else:
        print('Error(dict_file): invalid file name')
    
    return ans


'______________________________________________________________________________'


def text_to_words(text):
    """
    ----------------------------------------------------
    Parameters:   text (str)
    Return:       word_list (list)
    Description:  Reads a given text
                  Returns a list of strings, each pertaining to a word in the text
                  Words are separated by a white space (space, tab or newline)
                  Gets rid of all special characters at the start and at the end
    Asserts:      text is a string
    ---------------------------------------------------
    """    
    assert isinstance(text, str)
    
    ans = []
    newText = text.split()
    for i in range(len(newText)):
            curr = ''.join(char for char in newText[i] if char.isalnum() or char == "-")
            ans.append(curr)

    return ans


'______________________________________________________________________________'


def analyze_text(text, dict_list):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  dict_list (list)
    Return:       matches (int)
                  mismatches (int)
    Description:  Reads a given text, checks if each word appears in given dictionary
                  Returns number of matches and mismatches.
                  Words are compared in lowercase
                  Assumes a proper dict_list
    Asserts:      text is a string and dict_list is a list
    ---------------------------------------------------
    """
    assert isinstance(text, str)
    assert isinstance(dict_list, list)

    match = 0
    mismatch = 0
    currentList = text_to_words(text)
    
    for i in range(len(currentList)):
        currentWord = currentList[i]
        if(currentWord != ""):
            currentWord = currentWord.lower()
            SL = ord(currentWord[0]) - 97
            if(SL >= 0 and currentWord in dict_list[SL]):
                match = match + 1
    
            else:
                mismatch = mismatch + 1
                
        else:
            mismatch = mismatch + 1
            
    ans = (match, mismatch)
    return ans


'______________________________________________________________________________'


def is_plaintext(text, dict_list, threshold=0.9):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  dict_list (list): dictionary list
                  threshold (float): number between 0 to 1
                      default value = 0.9
    Return:       True/False
    Description:  Check if a given file is a plaintext
                  If #matches/#words >= threshold --> True
                      otherwise --> False
                  If invalid threshold, set to default value of 0.9
                  An empty text should return False
                  Assumes a valid dict_list is passed
    ---------------------------------------------------
    """
    ans = False
    correct = analyze_text(text, dict_list)
    fValue = correct[0] / (correct[0] + correct[1])
    
    if(fValue >= threshold):
        ans = True
    
    return ans


'______________________________________________________________________________'


def new_matrix(r, c, fill):
    """
    ----------------------------------------------------
    Parameters:   r: #rows (int)
                  c: #columns (int)
                  fill (str,int,double)
    Return:       matrix (2D List)
    Description:  Create an empty matrix of size r x c
                  All elements initialized to fill
                  minimum #rows and #columns = 2
                  If invalid value given, set to 2
    ---------------------------------------------------
    """
    if(isinstance(r, int) == False or r < 2):
        r = 2
        
    if(isinstance(c, int) == False or c < 2):
        c = 2
    
    rows, cols = (r, c)
    ans = [[fill] * cols] * rows
            
    return ans


'______________________________________________________________________________'


def print_matrix(matrix):
    """
    ----------------------------------------------------
    Parameters:   matrix (2D List)
    Return:       -
    Description:  prints a matrix each row in a separate line
                  items separated by a tab
                  Assumes given parameter is a valid matrix
    ---------------------------------------------------
    """
    rowNum = len(matrix)
    colNum = len(matrix[0])
    
    for _ in range(rowNum):
        for j in range(colNum):
            print(matrix[0][0], end="", flush=True)
            print("\t", end="", flush=True)
            if(j == colNum - 1):
                print("")
    
    return


'______________________________________________________________________________'


def index_2d(input_list, item):
    """
    ----------------------------------------------------
    Parameters:   input_list (list): 2D list
                  item (?)
    Return:       i (int): row number
                  j (int): column number
    Description:  Performs linear search on input list to find "item"
                  returns i,j, where i is the row number and j is the column number
                  if not found returns -1,-1
    Asserts:      input_list is a list
    ---------------------------------------------------
    """
    assert isinstance(input_list, list)
    ans = -1, -1
    
    found = False
    for i in range(len(input_list)):
        for j in range(len(input_list[i])):
            current = input_list[i][j]
            if(current == item):
                ans = i, j
                found = True
            if(found == True):
                break
            
        if(found == True):
            break
    
    return ans


'______________________________________________________________________________'


def shift_string(s, n, d='l'):
    """
    ----------------------------------------------------
    Parameters:   text (string): input string
                  shifts (int): number of shifts
                  direction (str): 'l' or 'r'
    Return:       update_text (str)
    Description:  Shift a given string by given number of shifts (circular shift)
                  If shifts is a negative value, direction is changed
                  If no direction is given or if it is not 'l' or 'r' set to 'l'
    Asserts:      text is a string and shifts is an integer
    ---------------------------------------------------
    """
    assert isinstance(s, str)
    assert isinstance(n, int)
    
    if(d == 'r'):
        n = n * (-1)
    
    shift = (n) % len(s)
    ans = s[shift: ] + s[: shift]
  
    return ans


'______________________________________________________________________________'


def matrix_to_string(matrix):
    """
    ----------------------------------------------------
    Parameters:   matrix (2D List)
    Return:       text (string)
    Description:  convert a 2D list of characters to a string
                  from top-left to right-bottom
                  Assumes given matrix is a valid 2D character list
    ---------------------------------------------------
    """
    ans = ""
    for i in range(len(matrix)):
        for j in range(len(matrix[i])):
            ans = ans + matrix[i][j]
    
    return ans


'______________________________________________________________________________'


def get_positions(text, base):
    """
    ----------------------------------------------------
    Parameters:   text (str): input string
                  base (str):  stream of unique characters
    Return:       positions (2D list)
    Description:  Analyzes a given text for any occurrence of base characters
                  Returns a 2D list with characters and their respective positions
                  format: [[char1,pos1], [char2,pos2],...]
                  Example: get_positions('I have 3 cents.','c.h') -->
                      [['h',2],['c',9],['.',14]]
                  items are ordered based on their occurrence in the text
    Asserts:      text and base are strings
    ---------------------------------------------------
    """
    assert isinstance(text, str)
    assert isinstance(base, str)
    
    ans = []
    
    for i in range(len(text)):
        currentChar = text[i]
        if(currentChar in base):
            currentPos = [currentChar, i]
            ans.append(currentPos)

    return ans


'______________________________________________________________________________'


def clean_text(text, base):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  base (str)
    Return:       updated_text (str)
    Description:  Constructs and returns a new text which has
                  all characters in original text after removing base characters
    Asserts:      text and base are strings
    ---------------------------------------------------
    """
    assert isinstance(text, str)
    assert isinstance(base, str)
    
    ans = ""
    
    for i in range(len(text)):
        currentChar = text[i]
        if(currentChar not in base):
            ans = ans + currentChar

    return ans


'______________________________________________________________________________'


def insert_positions(text, positions):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  positions (list): [[char1,pos1],[char2,pos2],...]]
    Return:       updated_text (str)
    Description:  Inserts all characters in the positions 2D list (generated by get_positions)
                  into their respective locations
                  Assumes a valid positions 2d list is given
    Asserts:      text is a string and positions is a list
    ---------------------------------------------------
    """
    assert isinstance(text, str)
    assert isinstance(positions, list)
    
    ans = ""
    arr1 = []
    
    for i in range(len(text)):
        arr1.append(text[i])
    
    for j in range(len(positions)):
        currentChar = positions[j][0]
        currentIndex = positions[j][1]
        arr1.insert(currentIndex, currentChar)
    
    for k in range(len(arr1)):
        ans = ans + arr1[k]
        
    return ans


'______________________________________________________________________________'


def text_to_blocks(text, b_size, padding=False, pad=PAD):
    """
    ----------------------------------------------------
    Parameters:   text (str): input string
                  block_size (int)
                  padding (bool): False(default) = no padding, True = padding
                  pad (str): padding character, default = PAD
    Return:       blocks (list)
    Description:  Create a list containing strings each of given block size
                  if padding flag is set, pad empty blocks using given padding character
                  if no padding character given, use global PAD
    Asserts:      text is a string and block_size is a positive integer
    ---------------------------------------------------
    """
    assert isinstance(text, str)
    assert isinstance(b_size, int) and b_size >= 0
    
    blocks = []
    currentStr = ""
    
    for i in range(len(text)):
        currentStr = currentStr + text[i]
        if(len(currentStr) == b_size):
            blocks.append(currentStr)
            currentStr = ""
    
    if(len(currentStr) > 0):
        if(padding == True):
            while(len(currentStr) < b_size):
                currentStr = currentStr + pad
        blocks.append(currentStr)
    
    return blocks


'______________________________________________________________________________'


def blocks_to_baskets(blocks):
    """
    ----------------------------------------------------
    Parameters:   blocks (list): list of equal size strings
    Return:       baskets: (list): list of equal size strings
    Description:  Create k baskets, where k = block_size
                  basket[i] contains the ith character from each block
    Errors:       if blocks are not strings or are of different sizes -->
                    print 'Error(blocks_to_baskets): invalid blocks', return []
    ----------------------------------------------------
    """
    currentBasket = ""
    baskets = []
    valid = True
    
    if(isinstance(blocks, list) == False):
        valid = False
    
    for i in range(len(blocks)):
        if(isinstance(blocks[i], str) == False):
            valid = False
    
    if(valid == True):
        startingLen = len(blocks[0])
        for i in range(len(blocks)):
            if(len(blocks[i]) != startingLen):
                valid = False
    
    if(valid == True):
        for i in range(len(blocks[0])):
            for j in range(len(blocks)):
                currentBasket = currentBasket + blocks[j][i]
                if(j == len(blocks) - 1):
                    baskets.append(currentBasket)
                    currentBasket = ""
    
    else:
        print("Error(blocks_to_baskets): invalid blocks")
        
    return baskets


'______________________________________________________________________________'


def compare_texts(text1, text2):
    """
    ----------------------------------------------------
    Parameters:   text1 (str)
                  text2 (str)
    Return:       matches (int)
    Description:  Compares two strings and returns number of matches
                  Comparison is done over character by character
    Assert:       text1 and text2 are strings
    ----------------------------------------------------
    """
    assert isinstance(text1, str)
    assert isinstance(text2, str)
    
    matches = 0
    len1 = len(text1)
    len2 = len(text2)
    shorter = 0
    
    if(len1 < len2):
        shorter = len1
        
    else:
        shorter = len2
        
    for i in range(shorter):
        if(text1[i] == text2[i]):
            matches = matches + 1
        
    return matches


'______________________________________________________________________________'


def get_freq(text, base=''):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  base (str): default = ''
    Return:       count_list (list of floats) 
    Description:  Finds character frequencies (count) in a given text
                  Default is English language (counts both upper and lower case)
                  Otherwise returns frequencies of characters defined in base
    Assert:       text is a string
    ----------------------------------------------------
    """
    assert isinstance(text, str)
    
    ans = []
    for i in range(len(base)):
        current = text.count(base[i])
        ans.append(current)
    
    return ans


'______________________________________________________________________________'


def is_binary(b):
    """
    ----------------------------------------------------
    Parameters:   b (str): binary number
    Return:       True/False
    Description:  Checks if given input is a string that represent a valid
                  binary number
                  An empty string, or a string that contains other than 0 or 1
                  should return False
    ---------------------------------------------------
    """
    ans = True
    
    if(b == ''):
        ans = False
    
    elif(isinstance(b, str) == False):
        ans = False
        
    else:
        for i in range(len(b)):
            if(b[i] != '0' and b[i] != '1'):
                ans = False
    
    return ans


'______________________________________________________________________________'


def bin_to_dec(b):
    """
    ----------------------------------------------------
    Parameters:   b (str): binary number
    Return:       decimal (int)
    Description:  Converts a binary number into corresponding integer
    Errors:       if not a valid binary number: 
                      print 'Error(bin_to_dec): invalid input' and return empty string
    ---------------------------------------------------
    """
    ans = []
    
    if(is_binary(b) == False):
        print("Error(bin_to_dec): invalid input")
        ans = ""

    else:
        ans = int(b, 2)
    
    return ans


'______________________________________________________________________________'


def dec_to_bin(decimal, size=None):
    """
    ----------------------------------------------------
    Parameters:   decimal (int): input decimal number
                  size (int): number of bits in output binary number
                      default size = None
    Return:       binary (str): output binary number
    Description:  Converts any integer to binary
                  Result is to be represented in size bits
                  pre-pad with 0's to fit the output in the given size
                  If no size is given, no padding is done 
    Asserts:      decimal is an integer
    Errors:       if an invalid size:
                      print 'Error(dec_to_bin): invalid size' and return ''
                  if size is too small to fit output binary number:
                      print 'Error(dec_to_bin): integer overflow' and return ''
    ---------------------------------------------------
    """
    assert isinstance(decimal, int)
    
    binary = bin(decimal).replace("0b", "")
    
    if(size != None and isinstance(size, int)):
        if(len(binary) < size):
            filler = (size - len(binary)) * "0"
            binary = filler + binary
            
        elif(size < 1):
            print("Error(dec_to_bin): invalid size")
            binary = ""
            
        elif(len(binary) > size):
            print("Error(dec_to_bin): integer overflow")
            binary = ""
            
    elif(size != None and isinstance(size, int) == False):
        print("Error(dec_to_bin): invalid size")
        binary = ""
            
    return binary


'______________________________________________________________________________'


def xor(a, b):
    """
    ----------------------------------------------------
    Parameters:   a (str): binary number
                  b (str): binary number
    Return:       decimal (int)
    Description:  Apply xor operation on a and b
    Errors:       if a or b is not a valid binary number 
                      print 'Error(xor): invalid input' and return ''
                  if a and b have different lengths:
                       print 'Error(xor): size mismatch' and return ''
    ---------------------------------------------------
    """
    ans = ""
    
    if(is_binary(a) == False or is_binary(b) == False):
        print("Error(xor): invalid input")
        
    elif(len(a) != len(b)):
        print("Error(xor): size mismatch")
    
    else:
        for i in range(len(a)):
            if(a[i] == b[i]):
                ans = ans + "0"
                
            else:
                ans = ans + "1"
        ans = int(ans)
        
    return ans


'______________________________________________________________________________'


def encode(c, code_type):
    """
    ----------------------------------------------------
    Parameters:   c (str): a character
                  code_type (str): ASCII or B6
    Return:       b (str): corresponding binary number
    Description:  Encodes a given character using the given encoding scheme
                  Current implementation supports only ASCII and B6 encoding
    Errors:       If c is not a single character:
                    print 'Error(encode): invalid input' and return ''
                  If unsupported encoding type:
                    print 'Error(encode): Unsupported Coding Type' and return ''
    ---------------------------------------------------
    """
    ans = ""
    
    if(isinstance(c, str) == False or len(c) != 1):
        print("Error(encode): invalid input")
    
    elif(code_type == "ASCII"):
        ans = ord(c)
        ans = dec_to_bin(ans, 8)
        
    elif(code_type == "B6"):
        base = get_base("B6")
        ans = base.find(str(c))
        ans = dec_to_bin(ans, 6)
        
    else:
        print("Error(encode): Unsupported coding type")
    
    return ans


'______________________________________________________________________________'


def decode(b, code_type):
    """
    ----------------------------------------------------
    Parameters:   b (str): a binary number
                  code_type (str): ASCII or B6
    Return:       c (str): corresponding character
    Description:  Encodes a given character using the given encoding scheme
                  Current implementation supports only ASCII and B6 encoding
    Errors:       If b is not a binary number:
                    print 'Error(decode): invalid input' and return ''
                  If unsupported encoding type:
                    print 'Error(decode): unsupported Coding Type' and return ''
    ---------------------------------------------------
    """
    ans = ""
    temp = {"0", "1"}
    if(isinstance(b, str)):
        res = set(b)
    
    if(isinstance(b, str) == False):
        print("Error(decode): invalid input")
    
    elif(res != temp and res != {'0'} and res != {'1'}):
        print("Error(decode): invalid input")
    
    elif(code_type == "ASCII"):
        ans = bin_to_dec(b)
        ans = chr(ans)
        
    elif(code_type == "B6"):
        if(len(b) != 6):
            print("Error(decode_B6): invalid input")
        
        else:
            base = get_base("B6")
            ans = bin_to_dec(b)
            ans = base[ans]
        
    else:
        print("Error(decode): unsupported coding type")
    
    return ans
