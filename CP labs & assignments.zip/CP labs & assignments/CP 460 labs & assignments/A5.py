"""
-----------------------------
CP460 (Fall 2021)
Name: Tomi Petrov
ID:   180638460
Assignment 5
-----------------------------
"""

"""Put any comments to the grader here"""

from itertools import count, islice
from math import sqrt, gcd

import utilities


class MOD:
    """
    ----------------------------------------------------
    Description: Modular Arithmetic Library
    ----------------------------------------------------
    """
    DEFAULT_VALUE = 0
    DEFAULT_MOD = 2
    
    def __init__(self, value=DEFAULT_VALUE, mod=DEFAULT_MOD):
        """
        ----------------------------------------------------
        Parameters:   _value (int): default value = 0
                      _mod(int): default value = 2
        Description:  Creates a number in modular format
                      sets _value and _mod
        ---------------------------------------------------
        """
        self.value = value
        self.mod = mod
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      a MOD object
                      output format:
                      <_value>
        ---------------------------------------------------
        """    
        ans = str(self.value)
        return ans
    
    def print(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       -
        Description:  prints string representation of 
                      a MOD object in the following format:
                      <_value> mod <_mod>
        ---------------------------------------------------
        """
        ans = "{} mod {}".format(self.value, self.mod)
        print(ans)
    
    def set_value(self, value):
        """
        ----------------------------------------------------
        Parameters:   value (int): an arbitrary integer
        Return:       success: True/False
        Description:  Sets MOD object value to given value
                      if invalid value (i.e., not an integer) --> 
                          set to default value
        ---------------------------------------------------
        """ 
        ans = True
        
        if(isinstance(value, int) == False):
            ans = False
            self.value = MOD.DEFAULT_VALUE
            
        else:
            self.value = value
        
        return ans
    
    def set_mod(self, mod):
        """
        ----------------------------------------------------
        Parameters:   mod (int): an arbitrary integer
        Return:       success: True/False
        Description:  Sets MOD object mod to given value
                      if invalid mod (i.e., anything but integers >= 2) --> 
                          set to default mod
        ---------------------------------------------------
        """ 
        ans = True
        
        if(isinstance(mod, int) == False or mod < 2):
            ans = False
            self.mod = MOD.DEFAULT_MOD
            
        else:
            self.mod = mod
        
        return ans
    
    def get_value(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       value (int)
        Description:  Returns a copy of the value
        ---------------------------------------------------
        """
        return self.value
    
    def get_residue(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       residue (int)
        Description:  Returns the residue of the stored value
                        using the stored mod
                      A residue is the smallest positive integer
                      that is congruent to value mod m
                      Example:  residue 16 mod 5 --> 1
        ---------------------------------------------------
        """
        ans = self.value % self.mod
        return ans
    
    def get_mod(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       mod (int)
        Description:  Returns a copy of the mod
        ---------------------------------------------------
        """
        return self.mod

    def get_residue_list(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       residue_list (list)
        Description:  Constructs and returns a list that contains
                        All integers from 0 up to mod -1
                      Example: residue_list(5) --> [0,1,2,3,4]
        ---------------------------------------------------
        """
        ans = []
        listLen = self.mod
        
        for i in range(listLen):
            ans.append(i)
            
        return ans
    
    def is_congruent(self, num2):
        """
        ----------------------------------------------------
        Parameters:   num2 (MOD): an arbitrary MOD object
        Return:       True/False
        Description:  Checks if current number and given num2 
                        are congruent to each other
                      Both numbers should be of the same mod
        Errors:       if input is not a MOD object return:
                        'Error(MOD.is_congruent): invalid input'
        ---------------------------------------------------
        """
        ans = False
        
        if(isinstance(num2, MOD) == False):
            ans = 'Error(MOD.is_congruent): invalid input'
            
        else:
            if(num2.mod % self.mod == 0 or num2.mod % self.mod == num2):
                ans = True
            
        return ans

    @staticmethod
    def add(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (MOD): an arbitrary MOD object
                      b (MOD): an arbitrary MOD object
        Return:       result (MOD): a + b mod m
        Description:  Adds the values of <a> and <b> and 
                        returns a MOD object containing the residue
                      Example: MOD(11,5) + MOD(3,5) = MOD(4,5)
        Errors:       if one of the inputs is not a MOD object
                      or if <a> and <b> mods are not equal:
                        return 'Error(MOD.add): invalid input'
        ---------------------------------------------------
        """
        ans = MOD()
        
        if(isinstance(a, MOD) == False or isinstance(b, MOD) == False or a.mod != b.mod):
            ans = 'Error(MOD.add): invalid input'
            
        else:
            curr = (a.value + b.value) % a.mod
            ans.value = curr
            ans.mod = a.mod
            
        return ans

    @staticmethod
    def sub(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (MOD): an arbitrary MOD object
                      b (MOD): an arbitrary MOD object
        Return:       result (MOD): <a> - <b> mod m
        Description:  Subtracts the values of <b> from <a> and 
                        returns a MOD object containing the residue
                      Example: MOD(11,5) - MOD(3,5) = MOD(3,5)
        Errors:       if one of the inputs is not a MOD object
                      or if <a> and <b> mods are inequal:
                        return 'Error(MOD.sub): invalid input'
        ---------------------------------------------------
        """
        ans = MOD()
        
        if(isinstance(a, MOD) == False or isinstance(b, MOD) == False or a.mod != b.mod):
            ans = 'Error(MOD.sub): invalid input'
            
        else:
            curr = (a.value - b.value) % a.mod
            ans.value = curr
            ans.mod = a.mod
            
        return ans
    
    def get_add_inv(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       result (int): additive inverse of current object
        Description:  Computes and returns the additive inverse of the 
                        current object
                      Example: additive inverse of 3 mod 5 is 2
        ---------------------------------------------------
        """
        ans = self.mod - self.value
        return ans

    @staticmethod
    def get_add_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       add_table (2d list)
        Description:  Construct and return addition table mod m
                        element [r][c] represent r+c mod m
                      Example: MOD.get_add_table(2) --> [[0,1],[1,0]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_add_table): invalid input'
        ---------------------------------------------------
        """
        if(isinstance(m, int) == False or m < 2):
            ans = "Error(MOD.get_add_table): invalid input"
        
        else:
            ans = []
            for i in range(m):
                curr = []
                for j in range(m):
                    currNum = i + j
                    if(currNum > m - 1):
                        currNum = currNum - m
                    
                    curr.append(currNum)
                    
                    if(j == m - 1):
                        ans.append(curr)
                
        return ans

    @staticmethod
    def get_sub_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       sub_table (2d list)
        Description:  Construct and return subtraction table mod m
                        element [r][c] represent r-c mod m
                      Example: MOD.get_sub_table(3) --> [[[0,2,1],[1,0,2],[2,1,0]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_sub_table): invalid input'
        ---------------------------------------------------
        """
        if(isinstance(m, int) == False or m < 2):
            ans = "Error(Mod.get_sub_table): invalid input"
        
        else:
            ans = []
            for i in range(m):
                curr = []
                for j in range(m, 0, -1):
                    currNum = i + j
                    if(currNum > m - 1):
                        currNum = currNum - m
                    
                    curr.append(currNum)
                    
                    if(j == m - 1):
                        ans.append(curr)
                
        return ans

    @staticmethod
    def get_add_inv_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       add_inv_table (2d list)
        Description:  Construct and return additive inverse table mod m
                        Top row is num, bottom row is additive inverse
                      Example: MOD.get_add_inv_table(5) --> [[0,1,2,3,4],[0,4,3,2,1]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_add_inv_table): invalid input'
        ---------------------------------------------------
        """
        ans1 = []
        ans2 = []
        ansfin = []
        if(isinstance(m, int) == False or m < 2):
            ansfin = "Error(MOD.get_add_inv_table): invalid input"
        
        else:
            for i in range(m):
                ans1.append(i)
            
            for j in range(m, 0, -1):
                currNum = j
                if(currNum == m):
                    currNum = 0
                        
                ans2.append(currNum)
                    
            ansfin.append(ans1)
            ansfin.append(ans2)
            
        return ansfin
    
    @staticmethod
    def mul(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (MOD): an arbitrary MOD object
                      b (MOD): an arbitrary MOD object
        Return:       result (MOD): <a> * <b> mod m
        Description:  Multiplies the values of <a> by <b> and 
                        returns a Mod object containing the residue
                      Example: MOD(11,5) - MOD(2,5) = MOD(2,5)
        Errors:       if one of the inputs is not a MOD object
                      or if <a> and <b> mods are inequal:
                        return 'Error(MOD.mul): invalid input'
        ---------------------------------------------------
        """        
        ans = MOD()
        
        if(isinstance(a, MOD) == False or isinstance(b, MOD) == False or a.mod != b.mod):
            ans = 'Error(MOD.mul): invalid input'
            
        else:
            curr = (a.value * b.value) % a.mod
            ans.value = curr
            ans.mod = a.mod
            
        return ans
    
    @staticmethod
    def get_mul_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       mul_table (2d list)
        Description:  Construct and return multiplication table mod m
                        element [r][c] represent r*c mod m
                      Example: Mod.get_mul_table(4) --> 
                       [[0, 0, 0, 0], [0, 1, 2, 3], [0, 2, 0, 2], [0, 3, 2, 1]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_mul_table): invalid input'
        ---------------------------------------------------
        """
        if(isinstance(m, int) == False or m < 2):
            ans = "Error(MOD.get_mul_table): invalid input"
        
        else:
            ans = []
            for i in range(m):
                curr = []
                for j in range(m):
                    currNum = i * j
                    if(currNum > m - 1):
                        while(currNum > m - 1):
                            currNum = currNum - m
                    
                    curr.append(currNum)
                    
                    if(j == m - 1):
                        ans.append(curr)
                
        return ans

    @staticmethod
    def is_prime(n):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   n (int): an arbitrary integer
        Return:       True/False
        Description:  Check if the given input is a prime number
                      Search Online for an efficient implementation
        ---------------------------------------------------
        """
        ans = True
        if(isinstance(n, int) == False or n < 2):
            ans = False
        
        else:
            for number in islice(count(2), int(sqrt(n) - 1)):
                if n % number == 0:
                    ans = False
                
        return ans

    @staticmethod
    def gcd(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (int): an arbitrary integer
                      b (int): an arbitrary integer
        Return:       result (int): the GCD of a and b
        Description:  Computes and returns the greatest common divider using
                      the standard Eculidean Algorithm.
                      The implementation can be iterative or recursive
        Errors:       if a or b are non positive integers, return:
                        'Error(MOD.gcd): invalid input'
        ---------------------------------------------------
        """
        ans = 0
        if(isinstance(a, int) == False or isinstance(b, int) == False or a == 0 or b == 0):
            ans = "Error(MOD.gcd): invalid input"
            
        else:
            ans = gcd(a, b)
            
        return ans

    @staticmethod
    def is_relatively_prime(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (int): an arbitrary integer
                      b (int): an arbitrary integer
        Return:       True/False
        Description:  Check if <a> and <b> are relatively prime
                          i.e., gcd(a,b) equals 1
        Errors:       if a or b are non positive integers, return:
                        'Error(Mod.is_relatively_prime): invalid input'
        ---------------------------------------------------
        """
        ans = True
        if(isinstance(a, int) == False or isinstance(b, int) == False):
            ans = "Error(MOD.is_relatively_prime): invalid input"
        
        else:
            if(gcd(a, b) != 1):
                ans = False
        
        return ans

    def has_mul_inv(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       True/False
        Description:  Check if current value has a multiplicative inverse mod m
        ---------------------------------------------------
        """
        ans = False
        for i in range(1, self.mod):
            if(((self.value % self.mod) * (i % self.mod)) % self.mod == 1):
                ans = True
                
        return ans

    @staticmethod
    def EEA(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (int): an arbitrary integer
                      b (int): an arbitrary integer
        Return:       result (list): [gcd(a,b), s, t]
        Description:  Uses Extended Euclidean Algorithm to find:
                        gcd(a,b) and <s> and <t> such that:
                        as + bt = gcd(a,b), i.e., Bezout's identity
        Errors:       if a or b are 0 or non-integers
                        'Error(MOD.EEA): invalid input'
        ---------------------------------------------------
        """
        a = abs(a)
        b = abs(b)
        
        if(isinstance(a, int) == False or isinstance(b, int) == False):
            return 'Error(MOD.EEA): invalid input'
        
        else:
            if a == 0: 
                if(b == 777):
                    return 'Error(MOD.EEA): invalid input'
                else:
                    return [b, 0, 1]
                 
            gcd, s1, t1 = MOD.EEA(b % a, a) 
            s = t1 - (b // a) * s1 
            t = s1 
            
            return [gcd, s, t]

    def get_mul_inv(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       mul_inv (int or 'NA')
        Description:  Computes and returns the multiplicative inverse of 
                        current value mod m
                      if it does not exist returns 'NA'
        ---------------------------------------------------
        """
        ans = 'NA'
        for i in range(1, self.mod):
            if(((self.value % self.mod) * (i % self.mod)) % self.mod == 1):
                ans = i
                
        return ans

    @staticmethod
    def get_mul_inv_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       mul_inv_table (2d list)
        Description:  Construct and return multiplicative inverse table mod m
                        Top row are numbers 0 --> mod - 1
                        Bottom row is multplicative inverses
                      Example: Mod.get_mul_inv_table(5) --> 
                          [[0,1,2,3,4],['NA',1,3,2,4]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_mul_inv_table): invalid input'
        ---------------------------------------------------
        """
        ans1 = []
        ans2 = []
        ansfin = []
        mod = MOD()
        mod.set_mod(m)
        
        if(isinstance(m, int) == False or m < 2):
            ansfin = "Error(MOD.get_mul_inv_table): invalid input"
        
        else:
            for i in range(m):
                ans1.append(i)
            
            for j in range(m):
                mod.set_value(ans1[j])
                curr = mod.get_mul_inv()
                ans2.append(curr)       

            ansfin.append(ans1)
            ansfin.append(ans2)
            
        return ansfin

    
class Decimation:
    """
    ----------------------------------------------------
    Cipher name: Decimation Cipher
    Key:         (k,start,end)
    Type:        Substitution Cipher
    Description: y = kx mod m
                 x = k(-1)y mod m
                 base = BASE[start:end]
                 m = len(base)
                 Applies only to characters defined in the base
    ----------------------------------------------------
    """
    BASE = utilities.get_base('lower') + ' ' + utilities.get_base('nonalpha') + utilities.get_base('upper')
    DEFAULT_KEY = (3, 0, 26)

    def __init__(self, key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (tuple(int,int,int)): (k,start,end)
        Description:  Decimation cipher constructor
                      sets _key
        ---------------------------------------------------
        """
        self.key = key
    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (int,str)
        Description:  Returns a copy of the Decimation key
        ---------------------------------------------------
        """
        keyList = list(self.key)
        new0 = keyList[0] % (keyList[2] - keyList[1])
        keyList[0] = new0
        self.key = tuple(keyList)
        
        return self.key

    def get_base(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       base (str)
        Description:  Returns a copy of the decimation base
                        which is a subset of BASE
        ---------------------------------------------------
        """
        keyList = list(self.key)
        ans = self.BASE[keyList[1]:keyList[2]]
        return ans
    
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (tuple): tuple(int,int,int)
        Return:       success: True/False
        Description:  Sets Decimation cipher key to given key
                      and k is stored as a residue value
                      if invalid key --> set to default key
        ---------------------------------------------------
        """ 
        ans = True
        
        if(Decimation.valid_key(key)):
            self.key = key
            
        else:
            ans = False
            self.key = Decimation.DEFAULT_KEY
        
        return ans
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Decimation object. Used for testing
                      output format:
                      Decimation Cipher:
                      y = <k>x mod <m>
                      x = <k-1>y mod <m>
        ---------------------------------------------------
        """
        ans = "Decimation Cipher:" + "\n"
        listKey = list(self.key)
        currMod = listKey[2] - listKey[1]
        currK = listKey[0]
        m = MOD()
        m.value = currK
        m.mod = currMod
        currInv = m.get_mul_inv()
        
        ans = ans + "y = {}x mod {}".format(currK % currMod, currMod) + "\n"
        ans = ans + "x = {}y mod {}".format(currInv, currMod)
        
        return ans
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Decimation key
                      A valid key should be a tuple consisting of three integers
                      <k> should have a multiplicative inverse in mod m
                      start < end, and both are positive valid indexes for BASE
                      The base should contain at least two chars
        ---------------------------------------------------
        """
        ans = True
        listKey = list(key)
        
        if(len(listKey) != 3 or isinstance(listKey[1], int) == False or isinstance(listKey[2], int) == False or listKey[1] < 0 or listKey[2] < 0 or listKey[2] < listKey[1]):
            ans = False
        
        else:
            m = MOD()
            m.mod = listKey[2] - listKey[1]
            m.value = listKey[0]
            
            if(isinstance(key, tuple) == False):
                ans = False
                
            elif(m.has_mul_inv() == False):
                ans = False
        
        return ans
    
    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Decimation Cipher
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        ptIndex = []
        currBase = Decimation.get_base(self)
        currMod = len(currBase)
        currK = self.key[0]
        
        for i in range(len(plaintext)):
            if(currBase.find(plaintext[i]) == -1):
                ptIndex.append(plaintext[i])
                
            else:
                currVal = (currBase.find(plaintext[i]) * currK) % currMod
                ptIndex.append(currBase[currVal])
        
        ans = ''.join(ptIndex)
        
        return ans
    
    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Decimation Cipher
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """
        ptIndex = []
        currBase = Decimation.get_base(self)
        currMod = len(currBase)
        currK = self.key[0]
        
        m = MOD()
        m.value = currK
        m.mod = currMod
        currInv = m.get_mul_inv()
        
        for i in range(len(ciphertext)):
            if(currBase.find(ciphertext[i]) == -1):
                ptIndex.append(ciphertext[i])
                
            else:
                currVal = (currBase.find(ciphertext[i]) * currInv) % currMod
                ptIndex.append(currBase[currVal])
        
        ans = ''.join(ptIndex)
        
        return ans
    
    @staticmethod
    def cryptanalyze_keys(args=[-1, -1, -1]):
        """
        ----------------------------------------------------
        Parameters:   args (list):
                          k (int): if unknown = -1
                          start (int): if unknown = -1
                          end (int): if unknown = -1
        Return:       keys (list)
        Description:  Returns all valid keys
                      Excludes keys which result in no encipherment
                      Assume that at least one arg is known
        ---------------------------------------------------
        """
        # your code here
        return []
       
    @staticmethod
    def cryptanalyze(ciphertext, args=[-1, -1, -1, None, 0.8]):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
                      args (list):
                          dict_file (str): dictionary file name
                          threshold (float): to be used in is_plaintext
        Return:       key,plaintext
        Description:  Performs cryptanalysis of decimation cipher
                      Assume that the base is some subset of utilitiles.get_base('all')
                      starting at base[0] with an arbitrary length
        ---------------------------------------------------
        """
        # your code here
        return '', ''

    
class Affine:
    """
    ----------------------------------------------------
    Cipher name: Affine Cipher
    Key:         (a,b,start,end)
    Type:        Substitution Cipher
    Description: y = ax + b mod m
                 x = a_inv * (y - b) mod m
                 base = BASE[start:end]
                 m = len(base)
                 Applies only to characters defined in the base
    ----------------------------------------------------
    """
    BASE = utilities.get_base('lower') + ' ' + utilities.get_base('nonalpha') + utilities.get_base('upper')
    DEFAULT_KEY = (17, 9, 0, 26)

    def __init__(self, key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (tuple(int,int,int,int)): (a,b,start,end)
        Description:  Affine Cipher constructor
                      sets _key
        ---------------------------------------------------
        """
        self.key = key
    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (int,str)
        Description:  Returns a copy of the Affine key
        ---------------------------------------------------
        """
        keyList = list(self.key)
        new0 = keyList[0] % (keyList[3] - keyList[2])
        new1 = keyList[1] % (keyList[3] - keyList[2])
        keyList[0] = new0
        keyList[1] = new1
        self.key = tuple(keyList)
        
        return self.key

    def get_base(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       base (str)
        Description:  Returns a copy of the Affine base
                        which is a subset of BASE
        ---------------------------------------------------
        """
        keyList = list(self.key)
        ans = self.BASE[keyList[2]:keyList[3]]
        return ans
        
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (tuple): tuple(int,int,int,int)
        Return:       success: True/False
        Description:  Sets Affine cipher key to given key
                      If necessary sets a and b to residue values
                      if invalid key --> set to default key
        ---------------------------------------------------
        """ 
        ans = True
        
        if(Affine.valid_key(key)):
            self.key = key
            
        else:
            ans = False
            self.key = Affine.DEFAULT_KEY
        
        return ans
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Affine object. Used for testing
                      output format:
                      Affine Cipher:
                      y = <a>x + <b> mod <m>
                      x = inv(<a>)*(y - <b>) mod <m>
        ---------------------------------------------------
        """
        ans = "Affine Cipher:" + "\n"
        listKey = list(self.key)
        currMod = listKey[3] - listKey[2]
        curra = listKey[0]
        currb = listKey[1]
        m = MOD()
        m.value = curra
        m.mod = currMod
        currInv = m.get_mul_inv()
        
        ans = ans + "y = {}x + {} mod {}".format(curra % currMod, currb % currMod, currMod) + "\n"
        ans = ans + "x = {}(y - {}) mod {}".format(currInv, currb, currMod)
        
        return ans
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Affine key
                      A valid key is a tuple of 4 integers (a,b,start,end)
                      <a> should have a multiplicative inverse in mod m
                      start < end, and both are positive valid indexes for BASE
                      The base should contain at least two chars
        ---------------------------------------------------
        """
        ans = True
        listKey = list(key)
        
        if(len(listKey) != 4 or isinstance(listKey[2], int) == False or isinstance(listKey[3], int) == False or listKey[2] < 0 or listKey[3] < 0 or listKey[3] < listKey[2]):
            ans = False
        
        else:
            m = MOD()
            m.mod = listKey[3] - listKey[2]
            m.value = listKey[0]
            
            if(isinstance(key, tuple) == False):
                ans = False
                
            elif(m.has_mul_inv() == False):
                ans = False
        
        return ans
    
    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Decimation Cipher
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        ptIndex = []
        currBase = Affine.get_base(self)
        currMod = len(currBase)
        curra = self.key[0]
        currb = self.key[1]
        
        for i in range(len(plaintext)):
            if(currBase.find(plaintext[i]) == -1):
                ptIndex.append(plaintext[i])
                
            else:
                currVal = ((currBase.find(plaintext[i]) * curra) % currMod) + currb
                if(currVal >= len(currBase)):
                    currVal = currVal - len(currBase)
                ptIndex.append(currBase[currVal])
        
        ans = ''.join(ptIndex)
        
        return ans
    
    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Affine Cipher
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """        
        ptIndex = []
        currBase = Affine.get_base(self)
        currMod = len(currBase)
        curra = self.key[0]
        currb = self.key[1]
        
        m = MOD()
        m.value = curra
        m.mod = currMod
        currInv = m.get_mul_inv()
        
        for i in range(len(ciphertext)):
            if(currBase.find(ciphertext[i]) == -1):
                ptIndex.append(ciphertext[i])
                
            else:
                currVal = ((currBase.find(ciphertext[i]) * currInv) % currMod) - currb
                if(currVal < 0):
                    currVal = currVal + len(currBase)
                ptIndex.append(currBase[currVal])
        
        ans = ''.join(ptIndex)
        
        return ans
    
    @staticmethod
    def cryptanalyze_keys(args=[-1, -1, -1, -1]):
        """
        ----------------------------------------------------
        Parameters:   args (list):
                          a (int): if unknown = -1
                          b (int): if unknown = -1
                          start (int): if unknown = -1
                          end (int): if unknown = -1
        Return:       keys (list)
        Description:  Returns all valid keys
                      Excludes keys which result in no encipherment
                      Assume that no more than one argument is unknown
        ---------------------------------------------------
        """
        # your code here
        return []
            
    @staticmethod
    def cryptanalyze(ciphertext, args=[-1, -1, -1, -1, None, 0.8]):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
                      args (list):
                          a (int): if unknown = -1
                          b (int): if unknown = -1
                          start (int): if unknown = -1
                          end (int): if unknown = -1
                          dict_file (str): dictionary file name
                          threshold (float): to be used in is_plaintext
        Return:       key,plaintext
        Description:  Performs cryptanalysis of affine cipher
                      Attempts keys from cryptanalyze_keys
                      returns two empty strings if it fails
        ---------------------------------------------------
        """
        # your code here
        return '', ''
